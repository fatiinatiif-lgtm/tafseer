import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart';
import 'designs.dart';

// ════════════════════════════════════════════════════════════
//  التاريخ (هجري + ميلادي)
// ════════════════════════════════════════════════════════════

const _gMonths = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
const _weekDays = ['الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'];
const _hMonths = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'];

class HijriDate {
  final int y;
  final int m;
  final int d;
  const HijriDate(this.y, this.m, this.d);
  String get text => '${ar(d)} ${_hMonths[m - 1]} ${ar(y)} هـ';
  String get short => '${ar(d)} ${_hMonths[m - 1]} ${ar(y)}';
}

// تحويل تقريبي (الحساب الجدولي)، ويمكن تعديله يومًا بالضغط المطوّل على التاريخ
HijriDate toHijri(DateTime g, {int adjust = 0}) {
  final dt = DateTime(g.year, g.month, g.day + adjust);
  final a = (14 - dt.month) ~/ 12;
  final y2 = dt.year + 4800 - a;
  final m2 = dt.month + 12 * a - 3;
  final jd = dt.day + (153 * m2 + 2) ~/ 5 + 365 * y2 + y2 ~/ 4 - y2 ~/ 100 + y2 ~/ 400 - 32045;
  var l = jd - 1948440 + 10632;
  final n = (l - 1) ~/ 10631;
  l = l - 10631 * n + 354;
  final j = ((10985 - l) ~/ 5316) * ((50 * l) ~/ 17719) + (l ~/ 5670) * ((43 * l) ~/ 15238);
  l = l - ((30 - j) ~/ 15) * ((17719 * j) ~/ 50) - (j ~/ 16) * ((15238 * j) ~/ 43) + 29;
  final m = (24 * l) ~/ 709;
  final d = l - (709 * m) ~/ 24;
  final y = 30 * n + j - 30;
  return HijriDate(y, m, d);
}

String gregText(DateTime d) => '${ar(d.day)} ${_gMonths[d.month - 1]} ${ar(d.year)} م';
String weekDayName(DateTime d) => _weekDays[d.weekday - 1];
String dayKey(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

Future<int> loadHijriAdjust() async {
  try {
    final p = await SharedPreferences.getInstance();
    return p.getInt('hijri_adjust') ?? 0;
  } catch (_) {
    return 0;
  }
}

Future<void> saveHijriAdjust(int v) async {
  try {
    final p = await SharedPreferences.getInstance();
    await p.setInt('hijri_adjust', v);
  } catch (_) {}
}

// ════════════════════════════════════════════════════════════
//  يوم الأهداف: من الفجر إلى الفجر
// ════════════════════════════════════════════════════════════

class FajrCity {
  final String name;
  final double lat;
  final double lng;
  final double angle; // زاوية الفجر بحسب هيئة المدينة
  const FajrCity(this.name, this.lat, this.lng, this.angle);
}

const fajrCities = <FajrCity>[
  FajrCity('القاهرة', 30.0444, 31.2357, 19.5),
  FajrCity('الإسكندرية', 31.2001, 29.9187, 19.5),
  FajrCity('الجيزة', 30.0131, 31.2089, 19.5),
  FajrCity('المنصورة', 31.0409, 31.3785, 19.5),
  FajrCity('طنطا', 30.7865, 31.0004, 19.5),
  FajrCity('الزقازيق', 30.5877, 31.5022, 19.5),
  FajrCity('بورسعيد', 31.2653, 32.3019, 19.5),
  FajrCity('السويس', 29.9668, 32.5498, 19.5),
  FajrCity('الإسماعيلية', 30.5965, 32.2715, 19.5),
  FajrCity('دمياط', 31.4165, 31.8133, 19.5),
  FajrCity('كفر الشيخ', 31.1107, 30.9388, 19.5),
  FajrCity('شبين الكوم', 30.5972, 30.9876, 19.5),
  FajrCity('بنها', 30.4660, 31.1848, 19.5),
  FajrCity('دمنهور', 31.0341, 30.4682, 19.5),
  FajrCity('الفيوم', 29.3084, 30.8428, 19.5),
  FajrCity('بني سويف', 29.0661, 31.0994, 19.5),
  FajrCity('المنيا', 28.1099, 30.7503, 19.5),
  FajrCity('أسيوط', 27.1783, 31.1859, 19.5),
  FajrCity('سوهاج', 26.5591, 31.6948, 19.5),
  FajrCity('قنا', 26.1551, 32.7160, 19.5),
  FajrCity('الأقصر', 25.6872, 32.6396, 19.5),
  FajrCity('أسوان', 24.0889, 32.8998, 19.5),
  FajrCity('العريش', 31.1317, 33.7984, 19.5),
  FajrCity('مرسى مطروح', 31.3543, 27.2373, 19.5),
  FajrCity('الغردقة', 27.2579, 33.8116, 19.5),
  FajrCity('شرم الشيخ', 27.9158, 34.3300, 19.5),
  FajrCity('مكة المكرمة', 21.3891, 39.8579, 18.5),
  FajrCity('المدينة المنورة', 24.5247, 39.5692, 18.5),
  FajrCity('جدة', 21.4858, 39.1925, 18.5),
  FajrCity('الرياض', 24.7136, 46.6753, 18.5),
  FajrCity('الدمام', 26.4207, 50.0888, 18.5),
  FajrCity('الكويت', 29.3759, 47.9774, 18.0),
  FajrCity('الدوحة', 25.2854, 51.5310, 18.0),
  FajrCity('دبي', 25.2048, 55.2708, 18.2),
  FajrCity('عمّان', 31.9454, 35.9284, 18.0),
  FajrCity('القدس', 31.7683, 35.2137, 18.0),
  FajrCity('بيروت', 33.8938, 35.5018, 18.0),
  FajrCity('دمشق', 33.5138, 36.2765, 18.0),
  FajrCity('بغداد', 33.3152, 44.3661, 18.0),
  FajrCity('الخرطوم', 15.5007, 32.5599, 19.5),
  FajrCity('طرابلس', 32.8872, 13.1913, 19.5),
  FajrCity('تونس', 36.8065, 10.1815, 18.0),
  FajrCity('الجزائر', 36.7538, 3.0588, 18.0),
  FajrCity('الرباط', 34.0209, -6.8416, 19.0),
];

double _rad(double d) => d * math.pi / 180;
double _deg(double r) => r * 180 / math.pi;
double _fixAngle(double a) => a - 360 * (a / 360).floor();
double _fixHour(double a) => a - 24 * (a / 24).floor();

double _julian(int y, int m, int d) {
  if (m <= 2) {
    y -= 1;
    m += 12;
  }
  final a = (y / 100).floor();
  final b = 2 - a + (a / 4).floor();
  return (365.25 * (y + 4716)).floor() + (30.6001 * (m + 1)).floor() + d + b - 1524.5;
}

// [الميل الشمسي، معادلة الزمن]
List<double> _sunPos(double jd) {
  final dd = jd - 2451545.0;
  final g = _fixAngle(357.529 + 0.98560028 * dd);
  final q = _fixAngle(280.459 + 0.98564736 * dd);
  final l = _fixAngle(q + 1.915 * math.sin(_rad(g)) + 0.020 * math.sin(_rad(2 * g)));
  final e = 23.439 - 0.00000036 * dd;
  final ra = _fixHour(_deg(math.atan2(math.cos(_rad(e)) * math.sin(_rad(l)), math.cos(_rad(l)))) / 15);
  final decl = _deg(math.asin(math.sin(_rad(e)) * math.sin(_rad(l))));
  return [decl, q / 15 - ra];
}

// وقت الفجر بالساعات (بتوقيت الجهاز) أو null إن لم يوجد حل
double? fajrHours(DateTime date, double lat, double lng, double angle) {
  final jd = _julian(date.year, date.month, date.day) - lng / (15 * 24);
  const t0 = 5 / 24;
  final sp = _sunPos(jd + t0);
  final noon = _fixHour(12 - sp[1]);
  final x = (-math.sin(_rad(angle)) - math.sin(_rad(sp[0])) * math.sin(_rad(lat))) / (math.cos(_rad(sp[0])) * math.cos(_rad(lat)));
  if (x < -1 || x > 1) return null;
  final t = _deg(math.acos(x)) / 15;
  final tz = DateTime(date.year, date.month, date.day, 12).timeZoneOffset.inMinutes / 60.0;
  return _fixHour(noon - t + tz - lng / 15);
}

String fmtTime12(DateTime t) {
  final h12 = t.hour % 12 == 0 ? 12 : t.hour % 12;
  return '${ar(h12)}:${ar(t.minute ~/ 10)}${ar(t.minute % 10)} ${t.hour < 12 ? 'ص' : 'م'}';
}

class GoalsClock {
  static FajrCity city = fajrCities[0];
  static final ValueNotifier<int> rev = ValueNotifier<int>(0);

  static Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final n = p.getString('fajr_city');
      for (final c in fajrCities) {
        if (c.name == n) city = c;
      }
    } catch (_) {}
  }

  static Future<void> setCity(FajrCity c) async {
    city = c;
    rev.value++;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('fajr_city', c.name);
    } catch (_) {}
  }

  // وقت الفجر في اليوم الميلادي المعطى
  static DateTime fajrOf(DateTime date) {
    final h = fajrHours(date, city.lat, city.lng, city.angle) ?? 5.0;
    return DateTime(date.year, date.month, date.day, 0, (h * 60).round());
  }

  // اليوم الحالي للأهداف: يبدأ عند الفجر وينتهي عند فجر اليوم التالي
  static DateTime currentDay([DateTime? now]) {
    final n = now ?? DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    return n.isBefore(fajrOf(today)) ? DateTime(today.year, today.month, today.day - 1) : today;
  }
}

class HomeDateCard extends StatefulWidget {
  const HomeDateCard({super.key});
  @override
  State<HomeDateCard> createState() => _HomeDateCardState();
}

class _HomeDateCardState extends State<HomeDateCard> {
  int adjust = 0;
  @override
  void initState() {
    super.initState();
    loadHijriAdjust().then((v) {
      if (mounted) setState(() => adjust = v);
    });
  }

  Future<void> _pick() async {
    final v = await showDialog<int>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: const Text('ضبط التاريخ الهجري'),
        children: [
          for (final o in const [[-1, 'يوم قبل'], [0, 'كما هو'], [1, 'يوم بعد']])
            SimpleDialogOption(
              onPressed: () => Navigator.pop(ctx, o[0] as int),
              child: Row(children: [
                Icon(adjust == o[0] ? Icons.radio_button_checked : Icons.radio_button_off, size: 20),
                const SizedBox(width: 10),
                Text(o[1] as String, style: const TextStyle(fontSize: 16)),
              ]),
            ),
        ],
      ),
    );
    if (v != null) {
      await saveHijriAdjust(v);
      if (mounted) setState(() => adjust = v);
    }
  }

  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    final now = DateTime.now();
    final h = toHijri(now, adjust: adjust);
    final top = Color.lerp(x.primary, x.highlight, x.dark ? 0.16 : 0.22)!;
    final bottom = Color.lerp(x.primary, Colors.black, 0.45)!;
    return GestureDetector(
      onLongPress: _pick,
      child: Container(
        width: double.infinity,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [top, x.primary, bottom]),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: x.highlight.withAlpha(200), width: 1.5),
          boxShadow: [BoxShadow(color: x.primary.withAlpha(100), blurRadius: 16, offset: const Offset(0, 7))],
        ),
        child: Stack(children: [
          Positioned.fill(child: CustomPaint(painter: PatternPainter(x.highlight.withAlpha(24)))),
          Positioned(top: -52, left: -52, child: Opacity(opacity: 0.28, child: CustomPaint(size: const Size(170, 170), painter: EmblemPainter(x.highlight, 0.2)))),
          Positioned(bottom: -52, right: -52, child: Opacity(opacity: 0.28, child: CustomPaint(size: const Size(170, 170), painter: EmblemPainter(x.highlight, 0.6)))),
          Positioned.fill(
            child: Padding(
              padding: const EdgeInsets.all(6),
              child: DecoratedBox(decoration: BoxDecoration(borderRadius: BorderRadius.circular(23), border: Border.all(color: x.highlight.withAlpha(95), width: 1))),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 22, 18, 16),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(weekDayName(now), style: TextStyle(fontFamily: kDeco, fontSize: 24, fontWeight: FontWeight.w700, color: x.highlight)),
              const SizedBox(height: 6),
              FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(h.text, style: const TextStyle(fontFamily: kDeco, fontSize: 36, fontWeight: FontWeight.w700, height: 1.5, color: Colors.white, shadows: [Shadow(color: Colors.black38, blurRadius: 4, offset: Offset(0, 1))])),
              ),
              const SizedBox(height: 4),
              OrnamentDivider(color: x.highlight),
              const SizedBox(height: 6),
              FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(gregText(now), style: TextStyle(fontFamily: kDeco, fontSize: 30, fontWeight: FontWeight.w700, height: 1.5, color: Colors.white.withAlpha(240))),
              ),
              const SizedBox(height: 4),
              Text('اضغط مطوّلًا لضبط التاريخ الهجري', style: TextStyle(fontSize: 11, color: Colors.white.withAlpha(120))),
            ]),
          ),
        ]),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
//  تتبع القراءة (الأهداف اليومية)
// ════════════════════════════════════════════════════════════

const bukhariChoices = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const salawatChoices = [2000, 3000, 4000, 5000];

String bukhariWord(int n) {
  if (n == 1) return 'باب';
  if (n == 2) return 'بابين';
  return '${ar(n)} أبواب';
}

class GoalRecord {
  bool tafsir;
  bool hizb;
  bool bukhari;
  bool salawat;
  int bukhariN;
  int salawatN;
  GoalRecord({this.tafsir = false, this.hizb = false, this.bukhari = false, this.salawat = false, this.bukhariN = 1, this.salawatN = 2000});
  int get doneCount => (tafsir ? 1 : 0) + (hizb ? 1 : 0) + (bukhari ? 1 : 0) + (salawat ? 1 : 0);
  bool get all => doneCount == 4;
  Map<String, dynamic> toJson() => {'t': tafsir, 'h': hizb, 'b': bukhari, 's': salawat, 'bn': bukhariN, 'sn': salawatN};
  static GoalRecord fromJson(Map<String, dynamic> j) => GoalRecord(
        tafsir: j['t'] == true,
        hizb: j['h'] == true,
        bukhari: j['b'] == true,
        salawat: j['s'] == true,
        bukhariN: (j['bn'] is int && bukhariChoices.contains(j['bn'])) ? j['bn'] as int : 1,
        salawatN: (j['sn'] is int && salawatChoices.contains(j['sn'])) ? j['sn'] as int : 2000,
      );
}

class GoalsStore {
  static const _prefix = 'goals_';
  static Future<GoalRecord> loadDay(DateTime d) async {
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getString('$_prefix${dayKey(d)}');
      if (raw != null) {
        return GoalRecord.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      }
      // يوم جديد: تُؤخذ آخر اختيارات للأبواب وعدد الصلاة
      final bn = p.getInt('goals_def_bukhari') ?? 1;
      final sn = p.getInt('goals_def_salawat') ?? 2000;
      final r = GoalRecord(bukhariN: bukhariChoices.contains(bn) ? bn : 1, salawatN: salawatChoices.contains(sn) ? sn : 2000);
      await p.setString('$_prefix${dayKey(d)}', jsonEncode(r.toJson()));
      return r;
    } catch (_) {
      return GoalRecord();
    }
  }

  static Future<void> saveDay(DateTime d, GoalRecord r) async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('$_prefix${dayKey(d)}', jsonEncode(r.toJson()));
      await p.setInt('goals_def_bukhari', r.bukhariN);
      await p.setInt('goals_def_salawat', r.salawatN);
    } catch (_) {}
  }

  static Future<Map<DateTime, GoalRecord>> loadAll() async {
    final out = <DateTime, GoalRecord>{};
    try {
      final p = await SharedPreferences.getInstance();
      for (final k in p.getKeys()) {
        if (!k.startsWith(_prefix) || k.startsWith('goals_def_')) continue;
        final parts = k.substring(_prefix.length).split('-');
        if (parts.length != 3) continue;
        final y = int.tryParse(parts[0]);
        final m = int.tryParse(parts[1]);
        final dd = int.tryParse(parts[2]);
        if (y == null || m == null || dd == null) continue;
        final raw = p.getString(k);
        if (raw == null) continue;
        out[DateTime(y, m, dd)] = GoalRecord.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      }
    } catch (_) {}
    return out;
  }
}

const _tafsirPraise = ['ما شاء الله، تبارك الله', 'نفع الله بك وبعلمك', 'فتح الله عليك فتح العارفين'];
const _hizbPraise = ['بارك الله في وقتك', 'جعل القرآن ربيع قلبك', 'ما شاء الله، ثبّتك الله'];
const _bukhariPraise = ['زادك الله علمًا ونورًا', 'رزقك الله حب نبيه ﷺ', 'ما شاء الله، بارك الله فيك'];
const _salawatPraise = ['اللهم صلِّ وسلِّم على سيدنا محمد', 'صلى الله عليه وسلم، ورزقك شفاعته', 'ما شاء الله، عمّر الله قلبك بحبه'];

const _congrats = [
  'ما شاء الله تبارك الله، أتممتَ أهدافك كلها اليوم',
  'تقبّل الله منك، وبارك في علمك وعمرك وعملك',
  'جعل الله القرآن ربيع قلبك ونور صدرك',
  'اللهم صلِّ وسلِّم على سيدنا محمد وعلى آله وصحبه',
];

class GoalsPage extends StatefulWidget {
  const GoalsPage({super.key});
  @override
  State<GoalsPage> createState() => _GoalsPageState();
}

class _GoalsPageState extends State<GoalsPage> with WidgetsBindingObserver {
  late String _day;
  Timer? _timer;
  @override
  void initState() {
    super.initState();
    _day = dayKey(GoalsClock.currentDay());
    WidgetsBinding.instance.addObserver(this);
    GoalsClock.rev.addListener(_checkDay);
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _checkDay());
  }
  void _checkDay() {
    final k = dayKey(GoalsClock.currentDay());
    if (mounted && k != _day) setState(() => _day = k);
  }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _checkDay();
  }
  @override
  void dispose() {
    _timer?.cancel();
    GoalsClock.rev.removeListener(_checkDay);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.fromLTRB(16, 14, 16, 30),
    children: [GoalsCard(key: ValueKey('goals_$_day'))],
  );
}

class GoalsCard extends StatefulWidget {
  const GoalsCard({super.key});
  @override
  State<GoalsCard> createState() => _GoalsCardState();
}

class _GoalsCardState extends State<GoalsCard> {
  GoalRecord? rec;
  late final DateTime today;
  @override
  void initState() {
    super.initState();
    today = GoalsClock.currentDay();
    GoalsStore.loadDay(today).then((r) {
      if (mounted) setState(() => rec = r);
    });
  }

  void _change(VoidCallback f) {
    setState(f);
    GoalsStore.saveDay(today, rec!);
  }

  Future<void> _pickCity() async {
    final c = await showDialog<FajrCity>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('اختر مدينتك لحساب وقت الفجر'),
        content: SizedBox(
          width: double.maxFinite,
          height: 420,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('يبدأ اليوم من الفجر وينتهي به. يُحسب الوقت تقريبيًا بتوقيت جهازك.', style: TextStyle(fontSize: 13, height: 1.6)),
            const SizedBox(height: 8),
            Expanded(
              child: ListView(children: [
                for (final c in fajrCities)
                  InkWell(
                    onTap: () => Navigator.pop(ctx, c),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Row(children: [
                        Icon(c.name == GoalsClock.city.name ? Icons.radio_button_checked : Icons.radio_button_off, size: 20),
                        const SizedBox(width: 10),
                        Text(c.name, style: const TextStyle(fontSize: 16)),
                      ]),
                    ),
                  ),
              ]),
            ),
          ]),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء'))],
      ),
    );
    if (c != null) {
      await GoalsClock.setCity(c);
      if (mounted) setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    final r = rec;
    final accent = x.textAccent;
    final seed = today.day;
    return Container(
      decoration: BoxDecoration(
        color: x.card,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: accent.withAlpha(90), width: 1.2),
        boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))],
      ),
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 16),
      child: r == null
          ? const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator()))
          : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Row(children: [
                SizedBox(
                  width: 92,
                  height: 92,
                  child: Stack(alignment: Alignment.center, children: [
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: r.doneCount / 4),
                      duration: const Duration(milliseconds: 700),
                      curve: Curves.easeOutCubic,
                      builder: (context, v, _) => CustomPaint(size: const Size(92, 92), painter: _GoalRingPainter(v, accent.withAlpha(40), r.all ? const Color(0xFFE5486B) : const Color(0xFF2E9B6B))),
                    ),
                    Column(mainAxisSize: MainAxisSize.min, children: [
                      Text('${ar(r.doneCount)}/${ar(4)}', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: x.ink)),
                      Text('مهام', style: TextStyle(fontSize: 11, color: x.muted)),
                    ]),
                  ]),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('الأهداف اليومية', style: TextStyle(fontFamily: kDeco, fontSize: 28, fontWeight: FontWeight.w700, color: accent)),
                    const SizedBox(height: 2),
                    Text('يبدأ اليوم من الفجر وينتهي به', style: TextStyle(fontSize: 12.5, color: x.muted)),
                    InkWell(
                      onTap: _pickCity,
                      borderRadius: BorderRadius.circular(10),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(Icons.wb_twilight, size: 16, color: accent),
                          const SizedBox(width: 4),
                          Flexible(
                            child: Text('الفجر ${fmtTime12(GoalsClock.fajrOf(DateTime.now()))} · ${GoalsClock.city.name}', style: TextStyle(fontSize: 12.5, color: accent, fontWeight: FontWeight.w700)),
                          ),
                          Icon(Icons.arrow_drop_down, size: 18, color: accent),
                        ]),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Wrap(spacing: 6, runSpacing: 4, children: [
                      TextButton.icon(
                        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GoalsLogPage())),
                        style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 10), minimumSize: const Size(0, 32), tapTargetSize: MaterialTapTargetSize.shrinkWrap, backgroundColor: accent.withAlpha(30)),
                        icon: const Icon(Icons.history, size: 17),
                        label: const Text('السجل'),
                      ),
                      TextButton.icon(
                        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GoalsExportPage(date: today, rec: r))),
                        style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 10), minimumSize: const Size(0, 32), tapTargetSize: MaterialTapTargetSize.shrinkWrap, backgroundColor: accent.withAlpha(30)),
                        icon: const Icon(Icons.ios_share, size: 17),
                        label: const Text('تصدير'),
                      ),
                    ]),
                  ]),
                ),
              ]),
              const SizedBox(height: 14),
              // رأس الجدول
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(color: accent.withAlpha(36), borderRadius: const BorderRadius.vertical(top: Radius.circular(16))),
                child: Row(children: [
                  Expanded(child: Text('المهمة', style: TextStyle(fontWeight: FontWeight.w700, color: x.ink))),
                  Text('تم', style: TextStyle(fontWeight: FontWeight.w700, color: x.ink)),
                  const SizedBox(width: 10),
                ]),
              ),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: accent.withAlpha(70)),
                  borderRadius: const BorderRadius.vertical(bottom: Radius.circular(16)),
                ),
                child: Column(children: [
                  _GoalRow(
                    icon: Icons.menu_book,
                    title: 'قراءة تفسير ربع من القرآن الكريم',
                    done: r.tafsir,
                    praise: _tafsirPraise[seed % _tafsirPraise.length],
                    onToggle: () => _change(() => r.tafsir = !r.tafsir),
                  ),
                  _GoalRow(
                    icon: Icons.auto_stories,
                    title: 'قراءة ${ar(6)} أحزاب من القرآن الكريم يوميًا',
                    done: r.hizb,
                    praise: _hizbPraise[seed % _hizbPraise.length],
                    onToggle: () => _change(() => r.hizb = !r.hizb),
                  ),
                  _GoalRow(
                    icon: Icons.local_library_outlined,
                    title: 'قراءة ${bukhariWord(r.bukhariN)} من صحيح البخاري',
                    hint: 'اختر عدد الأبواب',
                    choices: [for (final n in bukhariChoices) ar(n)],
                    selected: bukhariChoices.indexOf(r.bukhariN),
                    onSelect: (i) => _change(() => r.bukhariN = bukhariChoices[i]),
                    done: r.bukhari,
                    praise: _bukhariPraise[seed % _bukhariPraise.length],
                    onToggle: () => _change(() => r.bukhari = !r.bukhari),
                  ),
                  _GoalRow(
                    icon: Icons.favorite_border,
                    title: 'الصلاة على سيدنا النبي ${ar(r.salawatN)} مرة',
                    hint: 'اختر العدد',
                    choices: [for (final n in salawatChoices) ar(n)],
                    selected: salawatChoices.indexOf(r.salawatN),
                    onSelect: (i) => _change(() => r.salawatN = salawatChoices[i]),
                    done: r.salawat,
                    praise: _salawatPraise[seed % _salawatPraise.length],
                    onToggle: () => _change(() => r.salawat = !r.salawat),
                    last: true,
                  ),
                ]),
              ),
              const SizedBox(height: 14),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 500),
                child: r.all ? _CongratsPanel(key: const ValueKey('all'), seed: seed) : _EncourageLine(key: ValueKey(r.doneCount), done: r.doneCount),
              ),
            ]),
    );
  }
}

class _GoalRingPainter extends CustomPainter {
  final double value;
  final Color track;
  final Color color;
  const _GoalRingPainter(this.value, this.track, this.color);
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 7;
    canvas.drawCircle(c, r, Paint()..style = PaintingStyle.stroke..strokeWidth = 9..color = track);
    if (value > 0) {
      canvas.drawArc(
        Rect.fromCircle(center: c, radius: r),
        -math.pi / 2,
        2 * math.pi * value,
        false,
        Paint()..style = PaintingStyle.stroke..strokeWidth = 9..strokeCap = StrokeCap.round..color = color,
      );
    }
  }
  @override
  bool shouldRepaint(_GoalRingPainter old) => old.value != value || old.color != color || old.track != track;
}

class _GoalRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? hint;
  final List<String>? choices;
  final int selected;
  final ValueChanged<int>? onSelect;
  final bool done;
  final String praise;
  final VoidCallback onToggle;
  final bool last;
  const _GoalRow({
    required this.icon,
    required this.title,
    required this.done,
    required this.praise,
    required this.onToggle,
    this.hint,
    this.choices,
    this.selected = 0,
    this.onSelect,
    this.last = false,
  });
  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    final accent = x.textAccent;
    const green = Color(0xFF2E9B6B);
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 12, 10, 12),
      decoration: BoxDecoration(
        color: done ? green.withAlpha(x.dark ? 34 : 24) : null,
        border: last ? null : Border(bottom: BorderSide(color: accent.withAlpha(50))),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(shape: BoxShape.circle, color: accent.withAlpha(34)),
          child: Icon(icon, size: 20, color: accent),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w700, height: 1.5, color: x.ink, decoration: done ? TextDecoration.none : null)),
            if (choices != null) ...[
              const SizedBox(height: 6),
              Text(hint ?? '', style: TextStyle(fontSize: 12, color: x.muted)),
              const SizedBox(height: 4),
              Wrap(spacing: 6, runSpacing: 2, children: [
                for (int i = 0; i < choices!.length; i++)
                  ChoiceChip(
                    label: Text(choices![i], style: const TextStyle(fontSize: 13)),
                    selected: selected == i,
                    visualDensity: VisualDensity.compact,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    onSelected: (_) => onSelect?.call(i),
                  ),
              ]),
            ],
            if (done) ...[
              const SizedBox(height: 6),
              Row(children: [
                const Icon(Icons.favorite, size: 14, color: Color(0xFFE5486B)),
                const SizedBox(width: 6),
                Expanded(child: Text(praise, style: const TextStyle(fontSize: 13, color: green, fontWeight: FontWeight.w600))),
              ]),
            ],
          ]),
        ),
        const SizedBox(width: 6),
        GestureDetector(
          onTap: onToggle,
          behavior: HitTestBehavior.opaque,
          child: Padding(
            padding: const EdgeInsets.all(4),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: done ? green : Colors.transparent,
                border: Border.all(color: done ? green : accent.withAlpha(150), width: 2),
              ),
              child: done ? const Icon(Icons.check, color: Colors.white, size: 22) : null,
            ),
          ),
        ),
      ]),
    );
  }
}

class _EncourageLine extends StatelessWidget {
  final int done;
  const _EncourageLine({super.key, required this.done});
  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    final text = done == 0
        ? 'ابدأ يومك بذكر الله، وأنجِز أول مهمة'
        : done == 1
            ? 'بارك الله فيك، بداية مباركة'
            : done == 2
                ? 'ما شاء الله، أنتَ في منتصف الطريق'
                : 'اقتربتَ من إتمام أهداف اليوم، أحسنتَ';
    return Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.favorite, size: 16, color: Color(0xFFE5486B)),
      const SizedBox(width: 8),
      Flexible(child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 14, color: x.muted))),
      const SizedBox(width: 8),
      const Icon(Icons.favorite, size: 16, color: Color(0xFFE5486B)),
    ]);
  }
}

class _CongratsPanel extends StatelessWidget {
  final int seed;
  const _CongratsPanel({super.key, required this.seed});
  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.85, end: 1),
      duration: const Duration(milliseconds: 700),
      curve: Curves.easeOutBack,
      builder: (context, v, child) => Transform.scale(scale: v, child: child),
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFFB8335A), Color(0xFF7A1F4B), Color(0xFF4B1A55)]),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: x.highlight.withAlpha(210), width: 1.4),
        ),
        child: Column(children: [
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(Icons.favorite, size: 18, color: Colors.pink.shade100),
            const SizedBox(width: 6),
            Icon(Icons.favorite, size: 26, color: Colors.pink.shade200),
            const SizedBox(width: 6),
            const Icon(Icons.favorite, size: 36, color: Color(0xFFFF6B8E)),
            const SizedBox(width: 6),
            Icon(Icons.favorite, size: 26, color: Colors.pink.shade200),
            const SizedBox(width: 6),
            Icon(Icons.favorite, size: 18, color: Colors.pink.shade100),
          ]),
          const SizedBox(height: 10),
          Text('هنيئًا لك إنجاز اليوم', textAlign: TextAlign.center, style: TextStyle(fontFamily: kDeco, fontSize: 30, fontWeight: FontWeight.w700, color: x.highlight)),
          const SizedBox(height: 6),
          OrnamentDivider(color: x.highlight),
          const SizedBox(height: 8),
          for (int i = 0; i < _congrats.length; i++)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Padding(padding: const EdgeInsets.only(top: 6), child: Icon(Icons.favorite, size: 12, color: Colors.pink.shade200)),
                const SizedBox(width: 8),
                Expanded(child: Text(_congrats[(i + seed) % _congrats.length], style: const TextStyle(fontSize: 16, height: 1.7, color: Colors.white))),
              ]),
            ),
        ]),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
//  سجل الأهداف والإنجازات
// ════════════════════════════════════════════════════════════

class GoalsLogPage extends StatefulWidget {
  const GoalsLogPage({super.key});
  @override
  State<GoalsLogPage> createState() => _GoalsLogPageState();
}

class _GoalsLogPageState extends State<GoalsLogPage> {
  Map<DateTime, GoalRecord>? data;
  int adjust = 0;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final d = await GoalsStore.loadAll();
    final a = await loadHijriAdjust();
    if (mounted) {
      setState(() {
        data = d;
        adjust = a;
      });
    }
  }

  int _streak(List<DateTime> days, Map<DateTime, GoalRecord> m, {required bool current}) {
    // days: تنازليًا
    var cursor = GoalsClock.currentDay();
    if (current) {
      if (!(m[cursor]?.all ?? false)) cursor = DateTime(cursor.year, cursor.month, cursor.day - 1);
      var n = 0;
      while (m[cursor]?.all ?? false) {
        n++;
        cursor = DateTime(cursor.year, cursor.month, cursor.day - 1);
      }
      return n;
    }
    var best = 0;
    var run = 0;
    DateTime? prev;
    for (final d in days.reversed) {
      final ok = m[d]!.all;
      if (ok && prev != null && DateTime(prev.year, prev.month, prev.day + 1) == d && run > 0) {
        run++;
      } else {
        run = ok ? 1 : 0;
      }
      if (ok) prev = d;
      if (!ok) prev = null;
      if (run > best) best = run;
    }
    return best;
  }

  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    final m = data;
    return Scaffold(
      appBar: AppBar(
        title: const Text('سجل الأهداف والإنجازات'),
        actions: [
          IconButton(
            tooltip: 'الصور المحفوظة',
            icon: const Icon(Icons.photo_library_outlined),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GoalsImagesPage())),
          ),
        ],
      ),
      body: m == null
          ? const Center(child: CircularProgressIndicator())
          : m.isEmpty
              ? const Center(child: Padding(padding: EdgeInsets.all(30), child: Text('لا توجد سجلات بعد. ستظهر هنا أهدافك وإنجازاتك يومًا بيوم.', textAlign: TextAlign.center, style: TextStyle(fontSize: 16, height: 1.8))))
              : _content(context, x, m),
    );
  }

  Widget _content(BuildContext context, DesignExt x, Map<DateTime, GoalRecord> m) {
    final days = m.keys.toList()..sort((a, b) => b.compareTo(a));
    final full = days.where((d) => m[d]!.all).length;
    final cur = _streak(days, m, current: true);
    final best = _streak(days, m, current: false);
    var totalSalawat = 0;
    var totalBukhari = 0;
    for (final d in days) {
      if (m[d]!.salawat) totalSalawat += m[d]!.salawatN;
      if (m[d]!.bukhari) totalBukhari += m[d]!.bukhariN;
    }
    Widget stat(IconData i, String v, String l) => Expanded(
          child: Container(
            margin: const EdgeInsets.all(4),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
            decoration: BoxDecoration(color: x.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: x.textAccent.withAlpha(70))),
            child: Column(children: [
              Icon(i, color: x.textAccent, size: 22),
              const SizedBox(height: 6),
              Text(v, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: x.ink)),
              const SizedBox(height: 2),
              Text(l, textAlign: TextAlign.center, style: TextStyle(fontSize: 11.5, color: x.muted)),
            ]),
          ),
        );
    return ListView(padding: const EdgeInsets.all(14), children: [
      Row(children: [
        stat(Icons.event_available, ar(full), 'أيام اكتملت'),
        stat(Icons.local_fire_department_outlined, ar(cur), 'السلسلة الحالية'),
        stat(Icons.emoji_events_outlined, ar(best), 'أفضل سلسلة'),
      ]),
      Row(children: [
        stat(Icons.local_library_outlined, ar(totalBukhari), 'أبواب من البخاري'),
        stat(Icons.favorite_border, ar(totalSalawat), 'صلاة على النبي'),
      ]),
      const SizedBox(height: 10),
      for (final d in days) _dayCard(context, x, d, m[d]!),
    ]);
  }

  Widget _dayCard(BuildContext context, DesignExt x, DateTime d, GoalRecord r) {
    const green = Color(0xFF2E9B6B);
    Widget line(String t, bool ok) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(children: [
            Icon(ok ? Icons.check_circle : Icons.radio_button_unchecked, size: 19, color: ok ? green : x.muted),
            const SizedBox(width: 8),
            Expanded(child: Text(t, style: TextStyle(fontSize: 14, color: ok ? x.ink : x.muted))),
          ]),
        );
    final h = toHijri(d, adjust: adjust);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: x.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: (r.all ? green : x.textAccent).withAlpha(r.all ? 160 : 60)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${weekDayName(d)}، ${h.short}', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5, color: x.ink)),
              const SizedBox(height: 2),
              Text(gregText(d), style: TextStyle(fontSize: 12.5, color: x.muted)),
            ]),
          ),
          IconButton(
            tooltip: 'تصدير كصورة',
            visualDensity: VisualDensity.compact,
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => GoalsExportPage(date: d, rec: r))),
            icon: Icon(Icons.ios_share, size: 20, color: x.textAccent),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(color: (r.all ? green : x.textAccent).withAlpha(40), borderRadius: BorderRadius.circular(20)),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              if (r.all) const Padding(padding: EdgeInsets.only(left: 4), child: Icon(Icons.favorite, size: 14, color: Color(0xFFE5486B))),
              Text('${ar(r.doneCount)} / ${ar(4)}', style: TextStyle(fontWeight: FontWeight.w800, color: r.all ? green : x.textAccent)),
            ]),
          ),
        ]),
        const SizedBox(height: 8),
        line('تفسير ربع من القرآن الكريم', r.tafsir),
        line('${ar(6)} أحزاب من القرآن الكريم', r.hizb),
        line('${bukhariWord(r.bukhariN)} من صحيح البخاري', r.bukhari),
        line('الصلاة على النبي ${ar(r.salawatN)} مرة', r.salawat),
      ]),
    );
  }
}


// ════════════════════════════════════════════════════════════
//  تصدير الأهداف كصورة (حفظ داخل التطبيق ومشاركة)
// ════════════════════════════════════════════════════════════

List<MapEntry<String, bool>> goalLines(GoalRecord r) => [
      MapEntry('تفسير ربع من القرآن الكريم', r.tafsir),
      MapEntry('${ar(6)} أحزاب من القرآن الكريم', r.hizb),
      MapEntry('${bukhariWord(r.bukhariN)} من صحيح البخاري', r.bukhari),
      MapEntry('الصلاة على سيدنا النبي ${ar(r.salawatN)} مرة', r.salawat),
    ];

class GoalsShareImage extends StatelessWidget {
  final DateTime date;
  final GoalRecord rec;
  final int adjust;
  const GoalsShareImage({super.key, required this.date, required this.rec, required this.adjust});

  static const _bgTop = Color(0xFF0E5E6F);
  static const _bgBottom = Color(0xFF07313B);
  static const _gold = Color(0xFFE2B85B);
  static const _green = Color(0xFF3DBE8B);
  static const _red = Color(0xFFE5677F);

  @override
  Widget build(BuildContext context) {
    final h = toHijri(date, adjust: adjust);
    final lines = goalLines(rec);
    final done = rec.doneCount;
    return Container(
      width: 360,
      decoration: const BoxDecoration(
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [_bgTop, _bgBottom]),
      ),
      padding: const EdgeInsets.all(12),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: _gold.withAlpha(150), width: 1.3),
        ),
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 16),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('كتب التفاسير', textAlign: TextAlign.center, style: TextStyle(fontFamily: kDeco, fontSize: 22, fontWeight: FontWeight.w700, color: _gold)),
          const SizedBox(height: 4),
          const Text('الأهداف اليومية', textAlign: TextAlign.center, style: TextStyle(fontFamily: kDeco, fontSize: 38, fontWeight: FontWeight.w700, color: Colors.white)),
          const SizedBox(height: 2),
          const Center(child: OrnamentDivider(color: _gold)),
          const SizedBox(height: 6),
          Text('${weekDayName(date)} · ${h.text}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white)),
          const SizedBox(height: 2),
          Text(gregText(date), textAlign: TextAlign.center, style: TextStyle(fontSize: 13.5, color: Colors.white.withAlpha(190))),
          const SizedBox(height: 16),
          Center(
            child: SizedBox(
              width: 96,
              height: 96,
              child: Stack(alignment: Alignment.center, children: [
                CustomPaint(size: const Size(96, 96), painter: _GoalRingPainter(done / 4, Colors.white.withAlpha(36), rec.all ? const Color(0xFFFF6B8E) : _green)),
                Column(mainAxisSize: MainAxisSize.min, children: [
                  Text('${ar(done)}/${ar(4)}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Colors.white)),
                  Text('مهام منجزة', style: TextStyle(fontSize: 10.5, color: Colors.white.withAlpha(170))),
                ]),
              ]),
            ),
          ),
          const SizedBox(height: 16),
          for (final e in lines)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
              decoration: BoxDecoration(
                color: (e.value ? _green : _red).withAlpha(e.value ? 34 : 26),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: (e.value ? _green : _red).withAlpha(120)),
              ),
              child: Row(children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: e.value ? _green : _red),
                  child: Icon(e.value ? Icons.check : Icons.close, size: 19, color: Colors.white),
                ),
                const SizedBox(width: 10),
                Expanded(child: Text(e.key, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700, height: 1.5, color: Colors.white))),
                const SizedBox(width: 8),
                Text(e.value ? 'تم' : 'لم يتم', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: e.value ? _green : _red)),
              ]),
            ),
          const SizedBox(height: 6),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.favorite, size: 14, color: Color(0xFFFF6B8E)),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                rec.all ? 'ما شاء الله، أتممتَ أهداف اليوم كلها' : 'أُنجز ${ar(done)} من ${ar(4)} · وبقي ${ar(4 - done)}',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, height: 1.6, color: Colors.white.withAlpha(225)),
              ),
            ),
            const SizedBox(width: 8),
            const Icon(Icons.favorite, size: 14, color: Color(0xFFFF6B8E)),
          ]),
          const SizedBox(height: 10),
          Text('تقبّل الله منا ومنكم', textAlign: TextAlign.center, style: TextStyle(fontFamily: kDeco, fontSize: 18, fontWeight: FontWeight.w700, color: _gold.withAlpha(230))),
        ]),
      ),
    );
  }
}

Future<Directory> goalsImagesDir() async {
  final base = await getApplicationDocumentsDirectory();
  final d = Directory('${base.path}/goals_images');
  if (!await d.exists()) await d.create(recursive: true);
  return d;
}

String _stamp(DateTime n) =>
    '${dayKey(n)}_${n.hour.toString().padLeft(2, '0')}${n.minute.toString().padLeft(2, '0')}${n.second.toString().padLeft(2, '0')}';

class GoalsExportPage extends StatefulWidget {
  final DateTime date;
  final GoalRecord rec;
  const GoalsExportPage({super.key, required this.date, required this.rec});
  @override
  State<GoalsExportPage> createState() => _GoalsExportPageState();
}

class _GoalsExportPageState extends State<GoalsExportPage> {
  final GlobalKey _key = GlobalKey();
  int adjust = 0;
  bool busy = false;
  @override
  void initState() {
    super.initState();
    loadHijriAdjust().then((v) {
      if (mounted) setState(() => adjust = v);
    });
  }

  void _snack(String t) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));
  }

  Future<Uint8List?> _capture() async {
    try {
      final b = _key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (b == null) return null;
      final img = await b.toImage(pixelRatio: 3.0);
      final bd = await img.toByteData(format: ui.ImageByteFormat.png);
      return bd?.buffer.asUint8List();
    } catch (_) {
      return null;
    }
  }

  Future<void> _save() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final bytes = await _capture();
      if (bytes == null) {
        _snack('تعذّر إنشاء الصورة، حاول مرة أخرى');
        return;
      }
      final d = await goalsImagesDir();
      await File('${d.path}/goals_${dayKey(widget.date)}_${_stamp(DateTime.now()).split('_').last}.png').writeAsBytes(bytes);
      _snack('تم حفظ الصورة في التطبيق');
    } catch (_) {
      _snack('تعذّر حفظ الصورة، حاول مرة أخرى');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _share() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final bytes = await _capture();
      if (bytes == null) {
        _snack('تعذّر إنشاء الصورة، حاول مرة أخرى');
        return;
      }
      final tmp = await getTemporaryDirectory();
      final f = File('${tmp.path}/goals_${_stamp(DateTime.now())}.png');
      await f.writeAsBytes(bytes);
      await Share.shareXFiles([XFile(f.path, mimeType: 'image/png')], text: 'أهدافي اليومية - كتب التفاسير');
    } catch (_) {
      _snack('تعذّرت المشاركة، حاول مرة أخرى');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تصدير الأهداف'),
        actions: [
          IconButton(
            tooltip: 'الصور المحفوظة',
            icon: const Icon(Icons.photo_library_outlined),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GoalsImagesPage())),
          ),
        ],
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(12, 14, 12, 30), children: [
        Center(
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: RepaintBoundary(
              key: _key,
              child: GoalsShareImage(date: widget.date, rec: widget.rec, adjust: adjust),
            ),
          ),
        ),
        const SizedBox(height: 18),
        Row(children: [
          Expanded(
            child: FilledButton.icon(
              onPressed: busy ? null : _save,
              icon: const Icon(Icons.save_alt),
              label: const Text('حفظ في التطبيق'),
              style: FilledButton.styleFrom(minimumSize: const Size(0, 50)),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: FilledButton.tonalIcon(
              onPressed: busy ? null : _share,
              icon: const Icon(Icons.ios_share),
              label: const Text('مشاركة'),
              style: FilledButton.styleFrom(minimumSize: const Size(0, 50)),
            ),
          ),
        ]),
        const SizedBox(height: 10),
        const Text('تُحفظ الصورة داخل التطبيق، ويمكنك عرضها ومشاركتها لاحقًا من «الصور المحفوظة».', textAlign: TextAlign.center, style: TextStyle(fontSize: 12.5, height: 1.6)),
      ]),
    );
  }
}

class GoalsImagesPage extends StatefulWidget {
  const GoalsImagesPage({super.key});
  @override
  State<GoalsImagesPage> createState() => _GoalsImagesPageState();
}

class _GoalsImagesPageState extends State<GoalsImagesPage> {
  List<File>? files;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final out = <File>[];
    try {
      final d = await goalsImagesDir();
      await for (final e in d.list()) {
        if (e is File && e.path.toLowerCase().endsWith('.png')) out.add(e);
      }
      out.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
    } catch (_) {}
    if (mounted) setState(() => files = out);
  }

  String _caption(File f) {
    final name = f.path.split('/').last;
    final m = RegExp(r'goals_(\d{4})-(\d{2})-(\d{2})').firstMatch(name);
    if (m == null) return '';
    final d = DateTime(int.parse(m.group(1)!), int.parse(m.group(2)!), int.parse(m.group(3)!));
    return '${weekDayName(d)} ${gregText(d)}';
  }

  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    final fs = files;
    return Scaffold(
      appBar: AppBar(title: const Text('الصور المحفوظة')),
      body: fs == null
          ? const Center(child: CircularProgressIndicator())
          : fs.isEmpty
              ? const Center(child: Padding(padding: EdgeInsets.all(30), child: Text('لا توجد صور محفوظة بعد.', textAlign: TextAlign.center, style: TextStyle(fontSize: 16, height: 1.8))))
              : GridView.builder(
                  padding: const EdgeInsets.all(12),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.62),
                  itemCount: fs.length,
                  itemBuilder: (context, i) {
                    final f = fs[i];
                    return InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () async {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => GoalsImageViewer(file: f)));
                        _load();
                      },
                      child: Container(
                        decoration: BoxDecoration(color: x.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: x.textAccent.withAlpha(70))),
                        clipBehavior: Clip.antiAlias,
                        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                          Expanded(child: Image.file(f, fit: BoxFit.cover, alignment: Alignment.topCenter, errorBuilder: (c, e, s) => const Center(child: Icon(Icons.broken_image_outlined)))),
                          Padding(
                            padding: const EdgeInsets.all(8),
                            child: Text(_caption(f), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: x.ink)),
                          ),
                        ]),
                      ),
                    );
                  },
                ),
    );
  }
}

class GoalsImageViewer extends StatelessWidget {
  final File file;
  const GoalsImageViewer({super.key, required this.file});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الصورة'),
        actions: [
          IconButton(
            tooltip: 'مشاركة',
            icon: const Icon(Icons.ios_share),
            onPressed: () => Share.shareXFiles([XFile(file.path, mimeType: 'image/png')], text: 'أهدافي اليومية - كتب التفاسير'),
          ),
          IconButton(
            tooltip: 'حذف',
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('حذف الصورة'),
                  content: const Text('هل تريد حذف هذه الصورة؟'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
                    TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
                  ],
                ),
              );
              if (ok == true) {
                try {
                  await file.delete();
                } catch (_) {}
                if (context.mounted) Navigator.pop(context);
              }
            },
          ),
        ],
      ),
      body: InteractiveViewer(
        minScale: 0.8,
        maxScale: 5,
        child: Center(child: Image.file(file)),
      ),
    );
  }
}
