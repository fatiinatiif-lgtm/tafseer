import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'designs.dart';
import 'notes_export.dart';
import 'quotes.dart';
import 'package:share_plus/share_plus.dart';

void main() => runApp(const MirathApp());

const burgundy = Color(0xFF681B32);
const gold = Color(0xFFE4B83F);

class Book {
  final String title;
  final String asset;
  // لو الكتاب مقسوم لأجزاء: تُوضع الأجزاء هنا ويظهر الكتاب بطاقة واحدة في القائمة
  final List<Book> parts;
  const Book(this.title, this.asset, [this.parts = const <Book>[]]);
  bool get isMulti => parts.isNotEmpty;
}

Future<void> openBook(BuildContext context, Book b) async {
  await Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => b.isMulti ? BookPartsPage(book: b) : PdfReaderPage(book: b)),
  );
}

// ===== الكتب =====
// أضف كل كتاب هنا بالشكل: Book('اسم الكتاب', 'assets/books/اسم_الملف.pdf')
// وضع ملف الـ PDF في مجلد assets/books/
const tafsirBooks = <Book>[
  Book('الدر المنثور في التفسير بالمأثور للسيوطي', 'assets/books/tafsir_01_al_durr_al_manthur_p1.pdf', [
    Book('الدر المنثور في التفسير بالمأثور للسيوطي (١ من ٨)', 'assets/books/tafsir_01_al_durr_al_manthur_p1.pdf'),
    Book('الدر المنثور في التفسير بالمأثور للسيوطي (٢ من ٨)', 'assets/books/tafsir_01_al_durr_al_manthur_p2.pdf'),
    Book('الدر المنثور في التفسير بالمأثور للسيوطي (٣ من ٨)', 'assets/books/tafsir_01_al_durr_al_manthur_p3.pdf'),
    Book('الدر المنثور في التفسير بالمأثور للسيوطي (٤ من ٨)', 'assets/books/tafsir_01_al_durr_al_manthur_p4.pdf'),
    Book('الدر المنثور في التفسير بالمأثور للسيوطي (٥ من ٨)', 'assets/books/tafsir_01_al_durr_al_manthur_p5.pdf'),
    Book('الدر المنثور في التفسير بالمأثور للسيوطي (٦ من ٨)', 'assets/books/tafsir_01_al_durr_al_manthur_p6.pdf'),
    Book('الدر المنثور في التفسير بالمأثور للسيوطي (٧ من ٨)', 'assets/books/tafsir_01_al_durr_al_manthur_p7.pdf'),
    Book('الدر المنثور في التفسير بالمأثور للسيوطي (٨ من ٨)', 'assets/books/tafsir_01_al_durr_al_manthur_p8.pdf'),
  ]),
  Book('الفوز الكبير في أصول التفسير وبذيله فتح الخبير بما لا بد من حفظه', 'assets/books/tafsir_02_al_fawz_al_kabir.pdf'),
  Book('تفسير القشيري المسمى لطائف الإشارات', 'assets/books/tafsir_03_lataif_al_isharat_qushayri.pdf'),
  Book('مفاتيح الغيب للإمام فخر الدين الرازي', 'assets/books/tafsir_04_mafatih_al_ghayb_p1.pdf', [
    Book('مفاتيح الغيب للإمام فخر الدين الرازي (١ من ٢)', 'assets/books/tafsir_04_mafatih_al_ghayb_p1.pdf'),
    Book('مفاتيح الغيب للإمام فخر الدين الرازي (٢ من ٢)', 'assets/books/tafsir_04_mafatih_al_ghayb_p2.pdf'),
  ]),
  Book('تفسير النسفي', 'assets/books/tafsir_05_al_nasafi_p1.pdf', [
    Book('تفسير النسفي (١ من ٨)', 'assets/books/tafsir_05_al_nasafi_p1.pdf'),
    Book('تفسير النسفي (٢ من ٨)', 'assets/books/tafsir_05_al_nasafi_p2.pdf'),
    Book('تفسير النسفي (٣ من ٨)', 'assets/books/tafsir_05_al_nasafi_p3.pdf'),
    Book('تفسير النسفي (٤ من ٨)', 'assets/books/tafsir_05_al_nasafi_p4.pdf'),
    Book('تفسير النسفي (٥ من ٨)', 'assets/books/tafsir_05_al_nasafi_p5.pdf'),
    Book('تفسير النسفي (٦ من ٨)', 'assets/books/tafsir_05_al_nasafi_p6.pdf'),
    Book('تفسير النسفي (٧ من ٨)', 'assets/books/tafsir_05_al_nasafi_p7.pdf'),
    Book('تفسير النسفي (٨ من ٨)', 'assets/books/tafsir_05_al_nasafi_p8.pdf'),
  ]),
  Book('تفسير الإمام الغزالي', 'assets/books/tafsir_06_tafsir_al_ghazali.pdf'),
  Book('شرح عباس علوي مالكي على نظم الزمزمي في علم التفسير', 'assets/books/tafsir_07_sharh_abbas_maliki_nazm_zamzami.pdf'),
];

final allBooks = <Book>[...tafsirBooks];

class MirathApp extends StatefulWidget {
  const MirathApp({super.key});
  @override
  State<MirathApp> createState() => _MirathAppState();
}

class _MirathAppState extends State<MirathApp> {
  bool dark = false;
  bool started = false;
  final GlobalKey _appKey = GlobalKey();
  late final Listenable _prefs = Listenable.merge([AppPrefs.design, AppPrefs.eye, AppPrefs.eyeAppWide]);
  void _refresh() {
    if (mounted) setState(() {});
  }
  @override
  void initState() {
    super.initState();
    _prefs.addListener(_refresh);
    AppPrefs.load();
  }
  @override
  void dispose() {
    _prefs.removeListener(_refresh);
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    final spec = designSpecs[AppPrefs.design.value];
    final effDark = dark || spec.alwaysDark;
    final d = DesignExt.make(spec, dark);
    final scheme = ColorScheme.fromSeed(
      seedColor: spec.seed,
      brightness: effDark ? Brightness.dark : Brightness.light,
      primary: spec.seed,
      secondary: spec.highlight,
    );
    final filter = AppPrefs.eyeAppWide.value ? eyeFilter(AppPrefs.eye.value) : null;
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      builder: (context, child) {
        final body = KeyedSubtree(key: _appKey, child: child!);
        return Directionality(
          textDirection: TextDirection.rtl,
          child: filter == null ? body : ColorFiltered(colorFilter: filter, child: body),
        );
      },
      title: 'كتب التفاسير',
      theme: ThemeData(
        colorScheme: scheme,
        useMaterial3: true,
        scaffoldBackgroundColor: d.bg,
        appBarTheme: const AppBarTheme(centerTitle: true),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: d.id == 0 ? null : d.card,
          indicatorColor: d.id == 0 ? null : d.textAccent.withAlpha(60),
        ),
        extensions: <ThemeExtension<dynamic>>[d],
      ),
      home: started ? MainShell(dark: dark, onThemeChanged: (v) => setState(() => dark = v)) : SplashScreen(onDone: () => setState(() => started = true)),
    );
  }
}

const kDeco = 'ArefRuqaa';
const goldFaint = Color(0x1AE4B83F);
const goldLine = Color(0x66E4B83F);

bool isDarkCtx(BuildContext c) => Theme.of(c).brightness == Brightness.dark;

String booksLabel(int n) {
  if (n == 1) return 'كتاب واحد';
  if (n == 2) return 'كتابان';
  if (n >= 3 && n <= 10) return '${ar(n)} كتب';
  return '${ar(n)} كتابًا';
}

class PatternPainter extends CustomPainter {
  final Color color;
  final double cell;
  const PatternPainter(this.color, {this.cell = 48});
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9;
    for (double y = 0; y <= size.height + cell; y += cell) {
      for (double x = 0; x <= size.width + cell; x += cell) {
        _star(canvas, Offset(x, y), cell * 0.40, paint);
        _star(canvas, Offset(x + cell / 2, y + cell / 2), cell * 0.17, paint);
      }
    }
  }
  void _star(Canvas canvas, Offset o, double r, Paint p) {
    for (final a in const [0.0, math.pi / 4]) {
      final path = Path();
      for (int i = 0; i < 4; i++) {
        final ang = a + i * math.pi / 2;
        final pt = Offset(o.dx + r * math.cos(ang), o.dy + r * math.sin(ang));
        if (i == 0) {
          path.moveTo(pt.dx, pt.dy);
        } else {
          path.lineTo(pt.dx, pt.dy);
        }
      }
      path.close();
      canvas.drawPath(path, p);
    }
  }
  @override
  bool shouldRepaint(covariant PatternPainter old) => old.color != color || old.cell != cell;
}

class FramePainter extends CustomPainter {
  final Color color;
  const FramePainter(this.color);
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final outer = RRect.fromRectAndRadius(Rect.fromLTWH(18, 18, size.width - 36, size.height - 36), const Radius.circular(22));
    final inner = RRect.fromRectAndRadius(Rect.fromLTWH(27, 27, size.width - 54, size.height - 54), const Radius.circular(16));
    canvas.drawRRect(outer, p);
    p.strokeWidth = 0.8;
    canvas.drawRRect(inner, p);
    final fill = Paint()..color = color;
    final spots = [
      Offset(18, 18),
      Offset(size.width - 18, 18),
      Offset(18, size.height - 18),
      Offset(size.width - 18, size.height - 18),
      Offset(size.width / 2, 18),
      Offset(size.width / 2, size.height - 18),
    ];
    for (final o in spots) {
      final d = Path()
        ..moveTo(o.dx, o.dy - 7)
        ..lineTo(o.dx + 7, o.dy)
        ..lineTo(o.dx, o.dy + 7)
        ..lineTo(o.dx - 7, o.dy)
        ..close();
      canvas.drawPath(d, fill);
    }
  }
  @override
  bool shouldRepaint(covariant FramePainter old) => old.color != color;
}

class OrnamentDivider extends StatelessWidget {
  final Color color;
  final double width;
  const OrnamentDivider({super.key, this.color = gold, this.width = 220});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: width,
    height: 16,
    child: Row(children: [
      Expanded(child: Container(height: 1, decoration: BoxDecoration(gradient: LinearGradient(colors: [color, Colors.transparent])))),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Transform.rotate(angle: math.pi / 4, child: Container(width: 8, height: 8, color: color)),
      ),
      Expanded(child: Container(height: 1, decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.transparent, color])))),
    ]),
  );
}

class StarBadge extends StatelessWidget {
  final String text;
  final double size;
  const StarBadge(this.text, {super.key, this.size = 48});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: size,
    height: size,
    child: CustomPaint(
      painter: _StarPainter(),
      child: Center(child: Text(text, style: TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: size * 0.30))),
    ),
  );
}

class _StarPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final path = Path();
    for (int i = 0; i < 16; i++) {
      final rad = i.isEven ? r : r * 0.80;
      final ang = -math.pi / 2 + i * math.pi / 8;
      final pt = Offset(c.dx + rad * math.cos(ang), c.dy + rad * math.sin(ang));
      if (i == 0) {
        path.moveTo(pt.dx, pt.dy);
      } else {
        path.lineTo(pt.dx, pt.dy);
      }
    }
    path.close();
    canvas.drawPath(path, Paint()..color = burgundy);
    canvas.drawPath(
      path,
      Paint()
        ..color = gold
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6,
    );
  }
  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class SplashScreen extends StatefulWidget {
  final VoidCallback onDone;
  const SplashScreen({super.key, required this.onDone});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override
  void initState() {
    super.initState();
    c = AnimationController(vsync: this, duration: const Duration(seconds: 5));
    c.addStatusListener((st) {
      if (st == AnimationStatus.completed && mounted) widget.onDone();
    });
    c.forward();
  }
  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }
  double _iv(double t, double a, double b) => ((t - a) / (b - a)).clamp(0.0, 1.0).toDouble();
  Widget _goldText(String text, double size, Color hi) => ShaderMask(
    blendMode: BlendMode.srcIn,
    shaderCallback: (r) => LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color.lerp(hi, Colors.white, 0.55)!, hi, Color.lerp(hi, Colors.black, 0.35)!],
    ).createShader(r),
    child: FittedBox(
      fit: BoxFit.scaleDown,
      child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, color: Colors.white, fontSize: size, height: 1.55)),
    ),
  );
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: dx(context).primary,
    body: AnimatedBuilder(
      animation: c,
      builder: (context, _) {
        final t = c.value;
        final sx = dx(context);
        final hi = sx.highlight;
        final pr = sx.primary;
        final a1 = Curves.easeOut.transform(_iv(t, 0.04, 0.30));
        final a2 = Curves.easeOut.transform(_iv(t, 0.22, 0.52));
        final a3 = Curves.easeOut.transform(_iv(t, 0.44, 0.72));
        final a4 = Curves.easeOut.transform(_iv(t, 0.60, 0.86));
        final fadeOut = 1.0 - _iv(t, 0.94, 1.0);
        return Opacity(
          opacity: fadeOut,
          child: Stack(children: [
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: RadialGradient(center: const Alignment(0, -0.1), radius: 1.05, colors: [Color.lerp(pr, Colors.white, 0.2)!, pr, Color.lerp(pr, Colors.black, 0.45)!]),
                ),
              ),
            ),
            Positioned.fill(child: CustomPaint(painter: PatternPainter(hi.withAlpha(22)))),
            Positioned.fill(child: Opacity(opacity: a1, child: CustomPaint(painter: FramePainter(hi.withAlpha(102))))),
            SafeArea(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Opacity(
                      opacity: a1,
                      child: Transform.translate(
                        offset: Offset(0, -12 * (1 - a1)),
                        child: _goldText('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', 30, hi),
                      ),
                    ),
                    const SizedBox(height: 30),
                    Opacity(
                      opacity: a2,
                      child: Transform.scale(
                        scale: 0.85 + 0.15 * a2,
                        child: SizedBox(
                          width: 190,
                          height: 190,
                          child: Stack(alignment: Alignment.center, children: [
                            Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(colors: [hi.withAlpha(70), hi.withAlpha(0)]),
                              ),
                            ),
                            CustomPaint(size: const Size(176, 176), painter: EmblemPainter(hi, t * math.pi * 1.6)),
                            Icon(Icons.auto_stories, size: 64, color: hi),
                          ]),
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),
                    Opacity(
                      opacity: a3,
                      child: Transform.translate(
                        offset: Offset(0, 18 * (1 - a3)),
                        child: _goldText('كتب التفاسير', 66, hi),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Opacity(opacity: a3, child: OrnamentDivider(color: hi)),
                    const SizedBox(height: 14),
                    Opacity(
                      opacity: a4,
                      child: Text('تفاسير القرآن الكريم وأصول التفسير', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withAlpha(215), fontSize: 15, letterSpacing: 0.4, height: 1.6)),
                    ),
                  ]),
                ),
              ),
            ),
            Positioned(
              left: 90,
              right: 90,
              bottom: 56,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(2),
                child: LinearProgressIndicator(value: t, minHeight: 3, color: hi, backgroundColor: Colors.white12),
              ),
            ),
          ]),
        );
      },
    ),
  );
}

class EmblemPainter extends CustomPainter {
  final Color color;
  final double rot;
  const EmblemPainter(this.color, this.rot);
  Path _star(Offset c, double r, double a0) {
    final path = Path();
    for (int i = 0; i < 16; i++) {
      final ang = a0 + i * math.pi / 8;
      final rr = i.isEven ? r : r * 0.74;
      final pt = c + Offset(math.cos(ang), math.sin(ang)) * rr;
      if (i == 0) {
        path.moveTo(pt.dx, pt.dy);
      } else {
        path.lineTo(pt.dx, pt.dy);
      }
    }
    path.close();
    return path;
  }
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    Paint line(double w, int alpha) => Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = w
      ..color = color.withAlpha(alpha);
    canvas.drawCircle(c, r, line(1.2, 150));
    canvas.drawCircle(c, r * 0.80, line(1.0, 90));
    canvas.drawPath(_star(c, r * 0.97, rot), line(1.5, 200));
    canvas.drawPath(_star(c, r * 0.70, -rot * 0.8 + math.pi / 16), line(1.2, 140));
    canvas.drawCircle(c, r * 0.5, Paint()..color = color.withAlpha(28));
    canvas.drawCircle(c, r * 0.5, line(1.2, 170));
  }
  @override
  bool shouldRepaint(EmblemPainter old) => old.rot != rot || old.color != color;
}

class MainShell extends StatefulWidget {
  final bool dark;
  final ValueChanged<bool> onThemeChanged;
  const MainShell({super.key, required this.dark, required this.onThemeChanged});
  @override
  State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> with WidgetsBindingObserver {
  int tab = 0;
  final search = TextEditingController();
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    UsageTracker.instance.start();
  }
  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    UsageTracker.instance.pause();
    super.dispose();
  }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      UsageTracker.instance.resume();
    } else if (state == AppLifecycleState.paused || state == AppLifecycleState.hidden || state == AppLifecycleState.detached) {
      UsageTracker.instance.pause();
    }
  }
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onSearch: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchPage())), onOpenLog: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UsageLogPage()))),
      const LibraryPage(),
      MorePage(dark: widget.dark, onThemeChanged: widget.onThemeChanged),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('ميراث النبوة'),
          backgroundColor: dx(context).id == 0 ? Theme.of(context).colorScheme.surface : dx(context).bg,
          foregroundColor: dx(context).id == 0 ? null : dx(context).ink,
        ),
        body: IndexedStack(index: tab, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) {
            setState(() => tab = i);
            UsageTracker.instance.base = const ['الرئيسية', 'المكتبة', 'المزيد'][i];
          },
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'ميراث النبوة'),
            NavigationDestination(icon: Icon(Icons.more_horiz), label: 'المزيد'),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final VoidCallback onSearch;
  final VoidCallback onOpenLog;
  const HomePage({super.key, required this.onSearch, required this.onOpenLog});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    TextField(
      readOnly: true,
      onTap: onSearch,
      decoration: InputDecoration(hintText: 'ابحث عن كتاب أو قسم...', prefixIcon: const Icon(Icons.search), filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)),
    ),
    const SizedBox(height: 22),
    const MotivationCard(),
  ]);
}

class MotivationCard extends StatefulWidget {
  const MotivationCard({super.key});
  @override
  State<MotivationCard> createState() => _MotivationCardState();
}
class _MotivationCardState extends State<MotivationCard> {
  static const _secs = 9;
  late final List<int> _order;
  int _pos = 0;
  Timer? _timer;
  @override
  void initState() {
    super.initState();
    _order = List<int>.generate(motivationQuotes.length, (i) => i)..shuffle(math.Random());
    _restart();
  }
  void _restart() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: _secs), (_) => _next());
  }
  void _next() {
    if (!mounted) return;
    setState(() => _pos = (_pos + 1) % _order.length);
  }
  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    final top = Color.lerp(x.primary, x.highlight, x.dark ? 0.16 : 0.22)!;
    final bottom = Color.lerp(x.primary, Colors.black, 0.45)!;
    final quote = motivationQuotes[_order[_pos]];
    return GestureDetector(
      onTap: () {
        _next();
        _restart();
      },
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [top, x.primary, bottom]),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: x.highlight.withAlpha(200), width: 1.6),
          boxShadow: [BoxShadow(color: x.primary.withAlpha(110), blurRadius: 18, offset: const Offset(0, 8))],
        ),
        child: Stack(children: [
          Positioned.fill(child: CustomPaint(painter: PatternPainter(x.highlight.withAlpha(26)))),
          Positioned(top: -14, right: 6, child: Icon(Icons.format_quote, size: 110, color: x.highlight.withAlpha(46))),
          Positioned(bottom: -30, left: -6, child: Transform.rotate(angle: math.pi, child: Icon(Icons.format_quote, size: 110, color: x.highlight.withAlpha(34)))),
          Positioned.fill(
            child: Padding(
              padding: const EdgeInsets.all(5),
              child: DecoratedBox(
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(25), border: Border.all(color: x.highlight.withAlpha(90), width: 1)),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(22, 20, 22, 0),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.auto_awesome, size: 15, color: x.highlight),
                const SizedBox(width: 8),
                Text('نفحة لطالب العلم', style: TextStyle(fontFamily: kDeco, fontSize: 22, fontWeight: FontWeight.w700, color: x.highlight)),
                const SizedBox(width: 8),
                Icon(Icons.auto_awesome, size: 15, color: x.highlight),
              ]),
              const SizedBox(height: 8),
              OrnamentDivider(color: x.highlight),
              ConstrainedBox(
                constraints: const BoxConstraints(minHeight: 128),
                child: Center(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 700),
                    switchInCurve: Curves.easeOutCubic,
                    transitionBuilder: (child, anim) => FadeTransition(
                      opacity: anim,
                      child: SlideTransition(position: Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero).animate(anim), child: child),
                    ),
                    child: Padding(
                      key: ValueKey(_pos),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      child: Text(
                        quote,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontFamily: kDeco, fontSize: 25, fontWeight: FontWeight.w700, height: 1.95, color: Colors.white, shadows: [Shadow(color: Colors.black38, blurRadius: 4, offset: Offset(0, 1))]),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.fromLTRB(26, 0, 26, 16),
                child: TweenAnimationBuilder<double>(
                  key: ValueKey(_pos),
                  tween: Tween(begin: 0, end: 1),
                  duration: const Duration(seconds: _secs),
                  builder: (context, v, _) => ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(value: v, minHeight: 3, color: x.highlight, backgroundColor: x.highlight.withAlpha(50)),
                  ),
                ),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}
class _SearchPageState extends State<SearchPage> {
  String query = '';
  late final Place _place;
  @override
  void initState() {
    super.initState();
    _place = UsageTracker.instance.enter('البحث');
  }
  @override
  void dispose() {
    UsageTracker.instance.leave(_place);
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    final results = allBooks.where((b) => b.title.contains(query.trim())).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('البحث في المكتبة')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            autofocus: true,
            onChanged: (v) => setState(() => query = v),
            decoration: InputDecoration(
              hintText: 'اكتب اسم الكتاب...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: query.isEmpty ? null : IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() => query = '')),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ),
        Expanded(child: results.isEmpty
          ? const Center(child: Text('لا توجد نتائج مطابقة.'))
          : ListView.builder(
              itemCount: results.length,
              itemBuilder: (context, i) => ListTile(
                leading: const Icon(Icons.menu_book, color: burgundy),
                title: Text(results[i].title),
                onTap: () => openBook(context, results[i]),
              ),
            )),
      ]),
    );
  }
}

String ar(int n) => n.toString().split('').map((d) => String.fromCharCode(0x0660 + int.parse(d))).join();

class Mark {
  final int page;
  final String name;
  final int t;
  const Mark(this.page, this.name, this.t);
  Map<String, dynamic> toJson() => {'p': page, 'n': name, 't': t};
  static Mark fromJson(Map<String, dynamic> j) => Mark(j['p'] as int, j['n'] as String, (j['t'] as int?) ?? 0);
}

String marksLabel(int n) {
  if (n == 1) return 'علامة واحدة';
  if (n == 2) return 'علامتان';
  if (n >= 3 && n <= 10) return '${ar(n)} علامات';
  return '${ar(n)} علامة';
}

class Bookmarks {
  static String _key(Book b) => 'bms_${b.asset}';
  static Future<List<Mark>> load(Book b) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key(b));
    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List;
        return list.map((e) => Mark.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      } catch (_) {
        return <Mark>[];
      }
    }
    final old = p.getInt('bm_${b.asset}');
    if (old != null) return [Mark(old, 'علامة', 0)];
    return <Mark>[];
  }
  static Future<void> save(Book b, List<Mark> marks) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_key(b), jsonEncode(marks.map((m) => m.toJson()).toList()));
  }
  static Future<Map<String, int>> counts(List<Book> books) async {
    final map = <String, int>{};
    for (final b in books) {
      var n = 0;
      for (final x in (b.isMulti ? b.parts : <Book>[b])) {
        n += (await load(x)).length;
      }
      if (n > 0) map[b.asset] = n;
    }
    return map;
  }
}

const hlColors = <Color>[
  Color(0xFFFFF176),
  Color(0xFFAED581),
  Color(0xFFF8BBD0),
  Color(0xFF81D4FA),
  Color(0xFFFFCC80),
  Color(0xFFCE93D8),
  Color(0xFFEF9A9A),
];
const hlNames = ['أصفر', 'أخضر', 'وردي', 'أزرق', 'برتقالي', 'بنفسجي', 'أحمر'];

class Hl {
  final int id;
  final int page;
  final int color;
  final Rect rect; // مستطيل بإحداثيات نسبية (٠..١) داخل الصفحة
  final String note;
  const Hl(this.id, this.page, this.color, this.rect, this.note);
  Hl withNote(String n) => Hl(id, page, color, rect, n);
  double get minY => rect.top;
  double get maxY => rect.bottom;
  Map<String, dynamic> toJson() => {
        'i': id,
        'p': page,
        'c': color,
        'n': note,
        'r': [rect.left, rect.top, rect.right, rect.bottom].map((v) => (v * 10000).round() / 10000).toList(),
      };
  static Hl fromJson(Map<String, dynamic> j) {
    final c = ((j['c'] as int?) ?? 0).clamp(0, hlColors.length - 1).toInt();
    Rect r;
    if (j['r'] != null) {
      final v = (j['r'] as List).map((e) => (e as num).toDouble()).toList();
      r = Rect.fromLTRB(v[0], v[1], v[2], v[3]);
    } else {
      final f = (j['o'] as List).map((e) => (e as num).toDouble()).toList();
      double l = 1, t = 1, rr = 0, b = 0;
      for (int i = 0; i + 1 < f.length; i += 2) {
        l = math.min(l, f[i]);
        rr = math.max(rr, f[i]);
        t = math.min(t, f[i + 1]);
        b = math.max(b, f[i + 1]);
      }
      r = Rect.fromLTRB(l, (t - 0.012).clamp(0.0, 1.0).toDouble(), rr, (b + 0.012).clamp(0.0, 1.0).toDouble());
    }
    return Hl(j['i'] as int, j['p'] as int, c, r, (j['n'] as String?) ?? '');
  }
}

class HlStore {
  static String _k(Book b) => 'hl_${b.asset}';
  static Future<List<Hl>> load(Book b) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_k(b));
    if (raw == null) return <Hl>[];
    try {
      final list = jsonDecode(raw) as List;
      return list.map((e) => Hl.fromJson(Map<String, dynamic>.from(e as Map))).where((h) => h.rect.width > 0 && h.rect.height > 0).toList();
    } catch (_) {
      return <Hl>[];
    }
  }
  static Future<void> save(Book b, List<Hl> items) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_k(b), jsonEncode(items.map((h) => h.toJson()).toList()));
  }
}

void drawHlRect(Canvas canvas, Rect r, int color, Rect n, {bool multiply = true}) {
  final rr = Rect.fromLTRB(r.left + n.left * r.width, r.top + n.top * r.height, r.left + n.right * r.width, r.top + n.bottom * r.height);
  // multiply: يلوّن الخلفية البيضاء ويُبقي الحروف السوداء واضحة تمامًا
  canvas.drawRect(rr, multiply ? (Paint()..color = hlColors[color]..blendMode = BlendMode.multiply) : (Paint()..color = hlColors[color].withAlpha(80)));
  canvas.drawRect(
    rr,
    Paint()
      ..color = hlColors[color].withAlpha(255)
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.0, r.width * 0.004),
  );
}

class _HlThumbPainter extends CustomPainter {
  final Hl h;
  const _HlThumbPainter(this.h);
  @override
  void paint(Canvas canvas, Size size) => drawHlRect(canvas, Offset.zero & size, h.color, h.rect, multiply: false);
  @override
  bool shouldRepaint(covariant _HlThumbPainter old) => old.h != h;
}

class IndexItem {
  final String title;
  final int page;
  const IndexItem(this.title, this.page);
  Map<String, dynamic> toJson() => {'t': title, 'p': page};
  static IndexItem fromJson(Map<String, dynamic> j) => IndexItem(j['t'] as String, j['p'] as int);
}

int? parsePage(String s) {
  final t = s.trim().replaceAllMapped(RegExp('[٠-٩]'), (x) => (x[0]!.codeUnitAt(0) - 0x0660).toString());
  return int.tryParse(t);
}

class BookIndex {
  static String _k(Book b) => 'idx_${b.asset}';
  static String _ko(Book b) => 'idxoff_${b.asset}';
  static Future<List<IndexItem>> load(Book b) async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_k(b));
    if (raw == null) return <IndexItem>[];
    try {
      final list = jsonDecode(raw) as List;
      return list.map((e) => IndexItem.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) {
      return <IndexItem>[];
    }
  }
  static Future<void> save(Book b, List<IndexItem> items) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_k(b), jsonEncode(items.map((i) => i.toJson()).toList()));
  }
  static Future<int> loadOffset(Book b) async {
    final p = await SharedPreferences.getInstance();
    return p.getInt(_ko(b)) ?? 0;
  }
  static Future<void> saveOffset(Book b, int o) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt(_ko(b), o);
  }
}

class LibCategory {
  final String name;
  final IconData icon;
  const LibCategory(this.name, this.icon);
}

// أضف الأقسام هنا بالشكل: LibCategory('اسم القسم', Icons.menu_book)
const libCategories = <LibCategory>[
  LibCategory('كتب التفاسير', Icons.menu_book),
];

List<Book> booksFor(String category) {
  if (category == 'كتب التفاسير') return tafsirBooks;
  // أضف هنا شرط كل قسم: if (category == 'اسم القسم') return [...كتب القسم];
  return const <Book>[];
}

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});
  @override
  Widget build(BuildContext context) {
    final dsn = dx(context);
    if (dsn.id != 0) return DesignLibrary(x: dsn);
    final accent = isDarkCtx(context) ? gold : burgundy;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
      children: [
        const SizedBox(height: 6),
        Center(child: Text('أقسام المكتبة', style: TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, fontSize: 32, color: accent, height: 1.4))),
        const SizedBox(height: 2),
        const Center(child: OrnamentDivider(width: 200)),
        const SizedBox(height: 20),
        ...libCategories.map((c) => _CategoryCard(c: c)),
      ],
    );
  }
}

class _CategoryCard extends StatelessWidget {
  final LibCategory c;
  const _CategoryCard({required this.c});
  String get subtitle {
    if (c.name == 'كتب التفاسير') return 'تفاسير القرآن الكريم وأصول التفسير';
    return '';
  }
  @override
  Widget build(BuildContext context) {
    final count = booksFor(c.name).length;
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Material(
        borderRadius: BorderRadius.circular(26),
        clipBehavior: Clip.antiAlias,
        elevation: 4,
        shadowColor: Colors.black54,
        color: burgundy,
        child: InkWell(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookListPage(title: c.name, books: booksFor(c.name)))),
          child: Ink(
            height: 150,
            decoration: const BoxDecoration(
              gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF9A3A55), burgundy, Color(0xFF4A1020)]),
            ),
            child: Stack(children: [
              Positioned.fill(child: CustomPaint(painter: const PatternPainter(goldFaint))),
              Positioned(left: -26, bottom: -30, child: Icon(c.icon, size: 150, color: const Color(0x14E4B83F))),
              Padding(
                padding: const EdgeInsets.all(18),
                child: Row(children: [
                  Container(
                    width: 74,
                    height: 74,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0x26E4B83F), border: Border.all(color: gold, width: 1.6)),
                    child: Icon(c.icon, color: gold, size: 36),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(c.name, style: const TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, color: gold, fontSize: 30, height: 1.3)),
                      const SizedBox(height: 2),
                      Text(subtitle, style: const TextStyle(color: Colors.white70, fontSize: 13.5)),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(color: const Color(0x33000000), borderRadius: BorderRadius.circular(20), border: Border.all(color: goldLine)),
                        child: Text(booksLabel(count), style: const TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w600)),
                      ),
                    ]),
                  ),
                  const Icon(Icons.chevron_left, color: gold, size: 30),
                ]),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

class BookListPage extends StatefulWidget {
  final String title;
  final List<Book> books;
  const BookListPage({super.key, required this.title, required this.books});
  @override
  State<BookListPage> createState() => _BookListPageState();
}
class _BookListPageState extends State<BookListPage> {
  Map<String, int> marks = {};
  String q = '';
  final ctl = TextEditingController();
  late final Place _place;
  List<String>? _order;
  @override
  void initState() {
    super.initState();
    _place = UsageTracker.instance.enter(widget.title);
    _load();
    _loadOrder();
  }
  Future<void> _loadOrder() async {
    final p = await SharedPreferences.getInstance();
    final l = p.getStringList('order_${widget.title}');
    if (mounted) setState(() => _order = l);
  }
  List<Book> get _ordered {
    final o = _order;
    if (o == null || o.isEmpty) return widget.books;
    final rest = {for (final b in widget.books) b.asset: b};
    final res = <Book>[];
    for (final a in o) {
      final b = rest.remove(a);
      if (b != null) res.add(b);
    }
    res.addAll(rest.values);
    return res;
  }
  Future<void> _openReorder() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => ReorderBooksPage(title: widget.title, books: _ordered, defaults: widget.books)));
    _loadOrder();
  }
  Widget get _reorderBtn => IconButton(tooltip: 'ترتيب الكتب بنفسك', icon: const Icon(Icons.swap_vert), onPressed: _openReorder);
  @override
  void dispose() {
    UsageTracker.instance.leave(_place);
    ctl.dispose();
    super.dispose();
  }
  Future<void> _load() async {
    final m = await Bookmarks.counts(widget.books);
    if (mounted) setState(() => marks = m);
  }
  Widget _chip(IconData icon, String label, Color fg, Color bg) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 14, color: fg),
      const SizedBox(width: 4),
      Text(label, style: TextStyle(color: fg, fontSize: 12, fontWeight: FontWeight.w600)),
    ]),
  );
  @override
  Widget build(BuildContext context) {
    final dark = isDarkCtx(context);
    final accent = dark ? gold : burgundy;
    final all = _ordered;
    final key = q.trim();
    final shown = <int>[for (int i = 0; i < all.length; i++) if (key.isEmpty || all[i].title.contains(key)) i];
    final totalMarks = marks.values.fold<int>(0, (x, y) => x + y);
    final dsn = dx(context);
    if (dsn.id != 0) {
      return designBookListScaffold(
        context,
        dsn,
        title: widget.title,
        all: all,
        shown: shown,
        marks: marks,
        q: q,
        ctl: ctl,
        onQuery: (v) => setState(() => q = v),
        actions: [_reorderBtn],
        onOpen: (b) async {
          await openBook(context, b);
          _load();
        },
      );
    }
    return Scaffold(
      appBar: AppBar(
        backgroundColor: burgundy,
        foregroundColor: gold,
        title: Text(widget.title, style: const TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, fontSize: 24)),
        actions: [_reorderBtn],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
        itemCount: shown.isEmpty ? 3 : shown.length + 2,
        itemBuilder: (context, i) {
          if (i == 0) {
            return Container(
              margin: const EdgeInsets.only(bottom: 14),
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF9A3A55), burgundy, Color(0xFF4A1020)]),
                borderRadius: BorderRadius.circular(24),
                boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10, offset: Offset(0, 4))],
              ),
              child: Stack(children: [
                Positioned.fill(child: CustomPaint(painter: const PatternPainter(goldFaint))),
                Padding(
                  padding: const EdgeInsets.all(18),
                  child: Row(children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0x26E4B83F), border: Border.all(color: gold, width: 1.5)),
                      child: const Icon(Icons.auto_stories, color: gold, size: 30),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(booksLabel(all.length), style: const TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, color: gold, fontSize: 26, height: 1.3)),
                        const SizedBox(height: 2),
                        Text(totalMarks == 0 ? 'اضغط على أي كتاب لبدء القراءة.' : 'لديك ${marksLabel(totalMarks)} محفوظة.', style: const TextStyle(color: Colors.white, fontSize: 13.5)),
                      ]),
                    ),
                  ]),
                ),
              ]),
            );
          }
          if (i == 1) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: TextField(
                controller: ctl,
                onChanged: (v) => setState(() => q = v),
                decoration: InputDecoration(
                  hintText: 'ابحث في هذا القسم...',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: q.isEmpty
                      ? null
                      : IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () {
                            ctl.clear();
                            setState(() => q = '');
                          },
                        ),
                  filled: true,
                  fillColor: dark ? const Color(0xFF241F24) : Colors.white,
                  contentPadding: const EdgeInsets.symmetric(vertical: 0),
                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: const BorderSide(color: goldLine)),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: accent, width: 1.6)),
                ),
              ),
            );
          }
          if (shown.isEmpty) {
            return const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('لا توجد كتب مطابقة.')));
          }
          final idx = shown[i - 2];
          final b = all[idx];
          final mark = marks[b.asset];
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Material(
              color: dark ? const Color(0xFF241F24) : Colors.white,
              elevation: 2,
              shadowColor: Colors.black38,
              borderRadius: BorderRadius.circular(20),
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                onTap: () async {
                  await openBook(context, b);
                  _load();
                },
                child: Container(
                  decoration: const BoxDecoration(border: Border(right: BorderSide(color: gold, width: 4))),
                  padding: const EdgeInsets.all(14),
                  child: Row(children: [
                    StarBadge(ar(idx + 1)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(b.title, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15.5, height: 1.5)),
                        const SizedBox(height: 8),
                        mark != null
                            ? _chip(Icons.bookmark, marksLabel(mark), burgundy, const Color(0xFFFFE9A8))
                            : _chip(Icons.picture_as_pdf_outlined, 'PDF', Colors.grey.shade600, dark ? const Color(0x22FFFFFF) : const Color(0xFFF1EDE4)),
                      ]),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: goldLine, width: 1.4)),
                      child: Icon(Icons.chevron_left, color: accent),
                    ),
                  ]),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class BookPartsPage extends StatefulWidget {
  final Book book;
  const BookPartsPage({super.key, required this.book});
  @override
  State<BookPartsPage> createState() => _BookPartsPageState();
}

class _BookPartsPageState extends State<BookPartsPage> {
  Map<String, int> marks = {};
  @override
  void initState() {
    super.initState();
    _load();
  }
  Future<void> _load() async {
    final m = await Bookmarks.counts(widget.book.parts);
    if (mounted) setState(() => marks = m);
  }
  @override
  Widget build(BuildContext context) {
    final dark = isDarkCtx(context);
    final dsn = dx(context);
    final classic = dsn.id == 0;
    final bg = classic ? (dark ? const Color(0xFF241F24) : Colors.white) : dsn.card;
    final accent = classic ? (dark ? gold : burgundy) : dsn.textAccent;
    final parts = widget.book.parts;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: classic ? burgundy : null,
        foregroundColor: classic ? gold : null,
        title: Text(widget.book.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 28),
        itemCount: parts.length + 1,
        itemBuilder: (context, i) {
          if (i == 0) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Text('هذا الكتاب مقسّم إلى ${ar(parts.length)} أجزاء، اختر الجزء الذي تريد قراءته.', style: const TextStyle(fontSize: 14, height: 1.6)),
            );
          }
          final part = parts[i - 1];
          final mark = marks[part.asset];
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Material(
              color: bg,
              elevation: 2,
              shadowColor: Colors.black38,
              borderRadius: BorderRadius.circular(20),
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                onTap: () async {
                  await Navigator.push(context, MaterialPageRoute(builder: (_) => PdfReaderPage(book: part)));
                  _load();
                },
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(children: [
                    StarBadge(ar(i)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('الجزء ${ar(i)} من ${ar(parts.length)}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                        if (mark != null) ...[
                          const SizedBox(height: 6),
                          Text(marksLabel(mark), style: TextStyle(color: accent, fontSize: 12.5, fontWeight: FontWeight.w600)),
                        ],
                      ]),
                    ),
                    Icon(Icons.chevron_left, color: accent),
                  ]),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class ReorderBooksPage extends StatefulWidget {
  final String title;
  final List<Book> books;
  final List<Book> defaults;
  const ReorderBooksPage({super.key, required this.title, required this.books, required this.defaults});
  @override
  State<ReorderBooksPage> createState() => _ReorderBooksPageState();
}
class _ReorderBooksPageState extends State<ReorderBooksPage> {
  late List<Book> list = [...widget.books];
  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('order_${widget.title}', list.map((b) => b.asset).toList());
  }
  Future<void> _reset() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('order_${widget.title}');
    if (mounted) setState(() => list = [...widget.defaults]);
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      backgroundColor: burgundy,
      foregroundColor: gold,
      title: Text('ترتيب كتب ${widget.title}', style: const TextStyle(fontSize: 18)),
      actions: [IconButton(tooltip: 'الرجوع للترتيب الأصلي', icon: const Icon(Icons.restart_alt), onPressed: _reset)],
    ),
    body: Column(children: [
      const Padding(
        padding: EdgeInsets.fromLTRB(16, 12, 16, 6),
        child: Text('اسحب الكتاب من علامة ☰ إلى المكان الذي تريده. الترتيب يُحفظ تلقائيًا.', style: TextStyle(fontSize: 13)),
      ),
      Expanded(
        child: ReorderableListView.builder(
          buildDefaultDragHandles: false,
          itemCount: list.length,
          onReorder: (o, n) {
            if (n > o) n -= 1;
            setState(() {
              final b = list.removeAt(o);
              list.insert(n, b);
            });
            _save();
          },
          itemBuilder: (c, i) => ListTile(
            key: ValueKey(list[i].asset),
            leading: StarBadge(ar(i + 1)),
            title: Text(list[i].title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
            trailing: ReorderableDragStartListener(index: i, child: const Padding(padding: EdgeInsets.all(8), child: Icon(Icons.drag_handle, size: 28))),
          ),
        ),
      ),
    ]),
  );
}

class PdfReaderPage extends StatefulWidget {
  final Book book;
  const PdfReaderPage({super.key, required this.book});
  @override
  State<PdfReaderPage> createState() => _PdfReaderPageState();
}
class _PdfReaderPageState extends State<PdfReaderPage> {
  final controller = PdfViewerController();
  int page = 1;
  int total = 0;
  List<Mark> marks = [];
  List<IndexItem> index = [];
  int offset = 0;
  bool thumbVisible = false;
  Timer? _hideTimer;
  final _rects = <int, Rect>{};
  List<Hl> hls = [];
  PdfDocument? _doc;
  bool hlMode = false;
  int hlColor = 0;
  Timer? _lpTimer;
  int? _ptr;
  int _ptrCount = 0;
  Offset _downPos = Offset.zero;
  Offset _lastPos = Offset.zero;
  bool _drawing = false;
  int _livePage = 0;
  List<Offset> _livePts = [];
  final _viewerKey = GlobalKey();
  late final Place _place;

  @override
  void initState() {
    super.initState();
    _place = UsageTracker.instance.enter(sectionOf(widget.book), widget.book.title);
    controller.addListener(_poke);
  }
  @override
  void dispose() {
    controller.removeListener(_poke);
    _hideTimer?.cancel();
    _lpTimer?.cancel();
    UsageTracker.instance.leave(_place);
    super.dispose();
  }
  Widget _wrapMode(Widget viewer) => ValueListenableBuilder<bool>(
    valueListenable: AppPrefs.eyeAppWide,
    builder: (context, wide, _) => ValueListenableBuilder<int>(
      valueListenable: AppPrefs.eye,
      builder: (context, mode, _) {
        final f = wide ? null : eyeFilter(mode);
        return f == null ? viewer : ColorFiltered(colorFilter: f, child: viewer);
      },
    ),
  );

  // ---------- التلوين ----------
  void _paintHl(Canvas canvas, Rect pageRect, PdfPage pg) {
    final pn = pg.pageNumber;
    _rects[pn] = pageRect;
    for (final h in hls) {
      if (h.page == pn) drawHlRect(canvas, pageRect, h.color, h.rect);
    }
    if (_drawing && _livePage == pn && _livePts.length >= 2) drawHlRect(canvas, pageRect, hlColor, Rect.fromPoints(_livePts.first, _livePts.last));
  }

  Offset? _scene(Offset local) {
    try {
      return MatrixUtils.transformPoint(Matrix4.inverted(controller.value), local);
    } catch (_) {
      return null;
    }
  }

  Offset _norm(Offset s, Rect r) => Offset(
        ((s.dx - r.left) / r.width).clamp(0.0, 1.0).toDouble(),
        ((s.dy - r.top) / r.height).clamp(0.0, 1.0).toDouble(),
      );

  void _onDown(PointerDownEvent e) {
    _ptrCount++;
    if (_ptrCount > 1) {
      _lpTimer?.cancel();
      if (_drawing) _cancelStroke();
      return;
    }
    _ptr = e.pointer;
    _downPos = e.localPosition;
    _lastPos = e.localPosition;
    if (total == 0) return;
    if (hlMode) {
      _beginStroke(e.localPosition);
    } else {
      _lpTimer?.cancel();
      _lpTimer = Timer(const Duration(milliseconds: 550), () {
        if (!mounted || _ptrCount != 1 || hlMode) return;
        HapticFeedback.mediumImpact();
        setState(() => hlMode = true);
        _beginStroke(_lastPos);
      });
    }
  }

  void _onMove(PointerMoveEvent e) {
    if (e.pointer != _ptr) return;
    _lastPos = e.localPosition;
    if (!hlMode && (e.localPosition - _downPos).distance > 14) {
      _lpTimer?.cancel();
    }
    if (_drawing) _extendStroke(e.localPosition);
  }

  void _onUp(PointerEvent e) {
    _ptrCount = math.max(0, _ptrCount - 1);
    if (e.pointer != _ptr) return;
    _lpTimer?.cancel();
    _ptr = null;
    if (_drawing) {
      if (e is PointerCancelEvent) {
        _cancelStroke();
      } else {
        _endStroke();
      }
    }
  }

  void _beginStroke(Offset local) {
    final s = _scene(local);
    if (s == null) return;
    for (final e in _rects.entries) {
      if (e.value.contains(s)) {
        setState(() {
          _livePage = e.key;
          _livePts = [_norm(s, e.value)];
          _drawing = true;
        });
        return;
      }
    }
  }

  void _extendStroke(Offset local) {
    final r = _rects[_livePage];
    final s = _scene(local);
    if (r == null || s == null || _livePts.isEmpty) return;
    setState(() => _livePts = [_livePts.first, _norm(s, r)]);
  }

  void _cancelStroke() {
    setState(() {
      _drawing = false;
      _livePts = [];
    });
  }

  Future<void> _endStroke() async {
    final pts = _livePts;
    final pg = _livePage;
    if (pts.length < 2) {
      _cancelStroke();
      return;
    }
    final rect = Rect.fromPoints(pts.first, pts.last);
    if (rect.width < 0.03 || rect.height < 0.01) {
      _cancelStroke();
      return;
    }
    final h = Hl(DateTime.now().millisecondsSinceEpoch, pg, hlColor, rect, '');
    final updated = [...hls, h];
    setState(() {
      _drawing = false;
      _livePts = [];
      hls = updated;
    });
    await HlStore.save(widget.book, updated);
  }

  void _exitHl() {
    setState(() {
      hlMode = false;
      _drawing = false;
      _livePts = [];
    });
  }

  Future<void> _undoHl() async {
    if (hls.isEmpty) return;
    final last = hls.reduce((a, b) => a.id >= b.id ? a : b);
    final updated = hls.where((x) => x.id != last.id).toList();
    setState(() => hls = updated);
    await HlStore.save(widget.book, updated);
  }

  Widget _hlBar() => Row(children: [
    for (int i = 0; i < hlColors.length; i++)
      Expanded(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => setState(() => hlColor = i),
          child: Center(
            child: Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(color: hlColors[i], shape: BoxShape.circle, border: Border.all(color: Colors.white, width: hlColor == i ? 3 : 1)),
              child: hlColor == i ? const Icon(Icons.check, size: 16, color: Colors.black87) : null,
            ),
          ),
        ),
      ),
    IconButton(color: Colors.white, tooltip: 'تراجع عن آخر تلوين', onPressed: hls.isEmpty ? null : _undoHl, icon: const Icon(Icons.undo)),
    IconButton(color: Colors.white, tooltip: 'إنهاء التلوين', onPressed: _exitHl, icon: const Icon(Icons.check_circle_outline)),
  ]);

  Future<String?> _askNote(String initial) {
    final c = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ملحوظتي'),
        content: TextField(controller: c, autofocus: true, minLines: 3, maxLines: 8, decoration: const InputDecoration(hintText: 'اكتب ملحوظتك هنا...', border: OutlineInputBorder())),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('حفظ')),
        ],
      ),
    );
  }

  Widget _hlThumb(Hl h, double w) {
    final doc = _doc;
    if (doc == null || h.page < 1 || h.page > doc.pages.length) return const SizedBox.shrink();
    final pg = doc.pages[h.page - 1];
    final pageH = pg.width <= 0 ? w * 1.4 : w * pg.height / pg.width;
    final top = (h.minY - 0.015).clamp(0.0, 0.95).toDouble();
    final bottom = (h.maxY + 0.015).clamp(top + 0.06, 1.0).toDouble();
    final cropH = math.max(40.0, (bottom - top) * pageH);
    return Container(
      decoration: BoxDecoration(border: Border.all(color: hlColors[h.color], width: 2), borderRadius: BorderRadius.circular(6)),
      child: ClipRect(
        child: SizedBox(
          width: w,
          height: cropH,
          child: OverflowBox(
            alignment: Alignment.topLeft,
            minWidth: w,
            maxWidth: w,
            minHeight: pageH,
            maxHeight: pageH,
            child: Transform.translate(
              offset: Offset(0, -top * pageH),
              child: SizedBox(
                width: w,
                height: pageH,
                child: Stack(children: [
                  Positioned.fill(child: PdfPageView(document: doc, pageNumber: h.page)),
                  Positioned.fill(child: CustomPaint(painter: _HlThumbPainter(h))),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _exportNotes() async {
    final doc = _doc;
    if (doc == null || hls.isEmpty) {
      _snack('لا توجد ملحوظات لتصديرها');
      return;
    }
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(content: Row(children: [CircularProgressIndicator(), SizedBox(width: 16), Expanded(child: Text('جارٍ تجهيز ملف PDF...'))])),
    );
    try {
      final f = await buildNotesPdf(widget.book, hls, doc);
      if (!mounted) return;
      Navigator.of(context, rootNavigator: true).pop();
      await Share.shareXFiles([XFile(f.path, mimeType: 'application/pdf')], text: 'ملحوظاتي من كتاب ${widget.book.title}');
    } catch (_) {
      if (!mounted) return;
      Navigator.of(context, rootNavigator: true).pop();
      _snack('تعذّر إنشاء الملف، حاول مرة أخرى');
    }
  }

  void _showNotes() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) {
        final sorted = [...hls]..sort((a, b) {
            final c = a.page.compareTo(b.page);
            return c != 0 ? c : a.minY.compareTo(b.minY);
          });
        final w = MediaQuery.of(ctx).size.width - 64;
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.85),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Row(children: [
                  Expanded(child: Text('الملحوظات (${ar(sorted.length)})', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                  FilledButton.icon(
                    onPressed: sorted.isEmpty ? null : _exportNotes,
                    icon: const Icon(Icons.picture_as_pdf_outlined),
                    label: const Text('حفظ / إرسال PDF'),
                  ),
                ]),
              ),
              const Divider(height: 1),
              if (sorted.isEmpty)
                const Padding(padding: EdgeInsets.all(28), child: Text('لا توجد تلوينات بعد. اضغط ضغطة طويلة على أي صفحة لتبدأ التلوين، وستُحفظ هنا تلقائيًا.', textAlign: TextAlign.center))
              else
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
                    itemCount: sorted.length,
                    itemBuilder: (c, i) {
                      final h = sorted[i];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(12, 6, 6, 12),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                            Row(children: [
                              Container(width: 16, height: 16, decoration: BoxDecoration(color: hlColors[h.color], shape: BoxShape.circle)),
                              const SizedBox(width: 8),
                              Expanded(child: Text('صفحة ${ar(h.page)} · ${hlNames[h.color]}', style: const TextStyle(fontWeight: FontWeight.bold))),
                              IconButton(
                                tooltip: 'اكتب ملحوظة',
                                icon: const Icon(Icons.edit_note),
                                onPressed: () async {
                                  final n = await _askNote(h.note);
                                  if (n == null) return;
                                  final updated = hls.map((x) => x.id == h.id ? x.withNote(n) : x).toList();
                                  await HlStore.save(widget.book, updated);
                                  if (!mounted) return;
                                  setState(() => hls = updated);
                                  setSheet(() {});
                                },
                              ),
                              IconButton(
                                tooltip: 'حذف',
                                icon: const Icon(Icons.delete_outline),
                                onPressed: () async {
                                  if (!await _confirmText('هل تريد حذف هذا التلوين وملحوظته؟')) return;
                                  final updated = hls.where((x) => x.id != h.id).toList();
                                  await HlStore.save(widget.book, updated);
                                  if (!mounted) return;
                                  setState(() => hls = updated);
                                  setSheet(() {});
                                },
                              ),
                            ]),
                            InkWell(
                              onTap: () {
                                Navigator.pop(ctx);
                                controller.goToPage(pageNumber: h.page);
                              },
                              child: Center(child: _hlThumb(h, w)),
                            ),
                            if (h.note.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.fromLTRB(4, 10, 8, 0),
                                child: Text(h.note, style: const TextStyle(fontSize: 15, height: 1.6)),
                              ),
                          ]),
                        ),
                      );
                    },
                  ),
                ),
            ]),
          ),
        );
      }),
    );
  }

  void _poke() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(milliseconds: 1400), () {
      if (mounted && thumbVisible) setState(() => thumbVisible = false);
    });
    if (!thumbVisible) {
      scheduleMicrotask(() {
        if (mounted && !thumbVisible) setState(() => thumbVisible = true);
      });
    }
  }

  void _snack(String text) {
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(content: Text(text), duration: const Duration(seconds: 2)));
  }

  Future<String?> _askName(String title, String initial) {
    final c = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c, autofocus: true, maxLength: 60, decoration: const InputDecoration(hintText: 'اسم العلامة (اختياري)')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('حفظ')),
        ],
      ),
    );
  }

  Future<bool> _confirmDelete(Mark m) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف العلامة'),
        content: Text('هل تريد حذف "${m.name}"؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
        ],
      ),
    );
    return ok == true;
  }

  Future<void> _addMark() async {
    final p = page;
    final name = await _askName('علامة جديدة - صفحة ${ar(p)}', '');
    if (name == null) return;
    final m = Mark(p, name.isEmpty ? 'علامة صفحة ${ar(p)}' : name, DateTime.now().millisecondsSinceEpoch);
    final updated = [...marks, m];
    await Bookmarks.save(widget.book, updated);
    if (!mounted) return;
    setState(() => marks = updated);
    _snack('تم حفظ العلامة: ${m.name}');
  }

  void _showMarks() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) {
        final sorted = [...marks]..sort((a, b) => a.page.compareTo(b.page));
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.7),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Row(children: [
                  Expanded(child: Text('العلامات (${ar(sorted.length)})', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                  FilledButton.icon(
                    onPressed: () async {
                      Navigator.pop(ctx);
                      await _addMark();
                    },
                    icon: const Icon(Icons.bookmark_add_outlined),
                    label: const Text('علامة هنا'),
                  ),
                ]),
              ),
              const Divider(height: 1),
              if (sorted.isEmpty)
                const Padding(padding: EdgeInsets.all(28), child: Text('لا توجد علامات بعد.'))
              else
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: sorted.length,
                    itemBuilder: (c, i) {
                      final m = sorted[i];
                      return ListTile(
                        leading: CircleAvatar(backgroundColor: burgundy, child: Text(ar(m.page), style: const TextStyle(color: gold, fontSize: 13, fontWeight: FontWeight.bold))),
                        title: Text(m.name),
                        subtitle: Text('صفحة ${ar(m.page)}'),
                        onTap: () {
                          Navigator.pop(ctx);
                          controller.goToPage(pageNumber: m.page);
                        },
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(
                            icon: const Icon(Icons.edit_outlined),
                            onPressed: () async {
                              final n = await _askName('تعديل اسم العلامة', m.name);
                              if (n == null) return;
                              final updated = marks.map((x) => identical(x, m) ? Mark(x.page, n.isEmpty ? x.name : n, x.t) : x).toList();
                              await Bookmarks.save(widget.book, updated);
                              if (!mounted) return;
                              setState(() => marks = updated);
                              setSheet(() {});
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async {
                              if (!await _confirmDelete(m)) return;
                              final updated = marks.where((x) => !identical(x, m)).toList();
                              await Bookmarks.save(widget.book, updated);
                              if (!mounted) return;
                              setState(() => marks = updated);
                              setSheet(() {});
                            },
                          ),
                        ]),
                      );
                    },
                  ),
                ),
            ]),
          ),
        );
      }),
    );
  }

  void _goPrinted(int printed) {
    if (total == 0) return;
    final target = (printed + offset).clamp(1, total).toInt();
    controller.goToPage(pageNumber: target);
  }

  Future<IndexItem?> _itemDialog(String heading, {IndexItem? initial}) {
    final t = TextEditingController(text: initial?.title ?? '');
    final pg = TextEditingController(text: initial != null ? initial.page.toString() : (page - offset < 1 ? 1 : page - offset).toString());
    return showDialog<IndexItem>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(heading),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: t, autofocus: true, maxLength: 100, decoration: const InputDecoration(labelText: 'العنوان (باب / فصل / مسألة)')),
          TextField(controller: pg, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'رقم الصفحة في الكتاب')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              final n = parsePage(pg.text);
              final title = t.text.trim();
              if (title.isEmpty || n == null || n < 1) return;
              Navigator.pop(ctx, IndexItem(title, n));
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  Future<bool> _confirmText(String text) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تأكيد الحذف'),
        content: Text(text),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
        ],
      ),
    );
    return ok == true;
  }

  Future<void> _bulkAdd() async {
    final c = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إضافة عدة عناوين'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('اكتب كل عنوان في سطر، ورقم صفحته في آخر السطر. مثال:\nكتاب الطهارة 5\nباب الصلاة 23\nباب الزكاة 41', style: TextStyle(fontSize: 13)),
            const SizedBox(height: 10),
            TextField(controller: c, autofocus: true, minLines: 6, maxLines: 10, decoration: const InputDecoration(border: OutlineInputBorder())),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('إضافة')),
        ],
      ),
    );
    if (text == null) return;
    final re = RegExp(r'^(.*?)[\s\-–—:.…،,]*([0-9٠-٩]+)\s*$');
    final added = <IndexItem>[];
    for (final line in text.split('\n')) {
      final mt = re.firstMatch(line.trim());
      if (mt == null) continue;
      final title = mt.group(1)!.trim();
      final n = parsePage(mt.group(2)!);
      if (title.isEmpty || n == null || n < 1) continue;
      added.add(IndexItem(title, n));
    }
    if (added.isEmpty) {
      _snack('لم يُعثر على أسطر بالشكل المطلوب (عنوان ثم رقم).');
      return;
    }
    final updated = [...index, ...added];
    await BookIndex.save(widget.book, updated);
    if (!mounted) return;
    setState(() => index = updated);
    _snack('تمت إضافة ${ar(added.length)} عنوانًا إلى الفهرس');
  }

  Future<void> _setOffset() async {
    final c = TextEditingController(text: (offset + 1).toString());
    final n = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ضبط الترقيم'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('أحيانًا يختلف رقم الصفحة المطبوع في الكتاب عن رقم صفحة الـ PDF. اكتب رقم صفحة الـ PDF التي تحمل الرقم ١ في الكتاب (مثلًا ٧ إذا بدأ ترقيم الكتاب بعد ست صفحات).', style: TextStyle(fontSize: 13)),
          const SizedBox(height: 10),
          TextField(controller: c, keyboardType: TextInputType.number, autofocus: true),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, parsePage(c.text)), child: const Text('حفظ')),
        ],
      ),
    );
    if (n == null || n < 1 || (total > 0 && n > total)) return;
    await BookIndex.saveOffset(widget.book, n - 1);
    if (!mounted) return;
    setState(() => offset = n - 1);
    _snack('تم ضبط الترقيم');
  }

  void _showIndex() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) {
        final sorted = [...index]..sort((a, b) => a.page.compareTo(b.page));
        return SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.78),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 8, 4),
                child: Row(children: [
                  Expanded(child: Text('الفهرس (${ar(sorted.length)})', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                  IconButton(
                    tooltip: 'ضبط الترقيم',
                    icon: const Icon(Icons.tune),
                    onPressed: () async {
                      await _setOffset();
                      setSheet(() {});
                    },
                  ),
                  IconButton(
                    tooltip: 'إضافة عدة عناوين',
                    icon: const Icon(Icons.playlist_add),
                    onPressed: () async {
                      await _bulkAdd();
                      setSheet(() {});
                    },
                  ),
                  FilledButton.icon(
                    onPressed: () async {
                      final it = await _itemDialog('عنوان جديد');
                      if (it == null) return;
                      final updated = [...index, it];
                      await BookIndex.save(widget.book, updated);
                      if (!mounted) return;
                      setState(() => index = updated);
                      setSheet(() {});
                    },
                    icon: const Icon(Icons.add),
                    label: const Text('عنوان'),
                  ),
                ]),
              ),
              const Divider(height: 1),
              if (sorted.isEmpty)
                const Padding(padding: EdgeInsets.all(28), child: Text('لا يوجد فهرس لهذا الكتاب بعد. أضف عناوين الأبواب مع أرقام صفحاتها، ثم اضغط على أي عنوان للانتقال إليه.', textAlign: TextAlign.center))
              else
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: sorted.length,
                    itemBuilder: (c, i) {
                      final it = sorted[i];
                      return ListTile(
                        leading: CircleAvatar(backgroundColor: burgundy, child: Text(ar(it.page), style: const TextStyle(color: gold, fontSize: 12, fontWeight: FontWeight.bold))),
                        title: Text(it.title),
                        onTap: () {
                          Navigator.pop(ctx);
                          _goPrinted(it.page);
                        },
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(
                            icon: const Icon(Icons.edit_outlined),
                            onPressed: () async {
                              final n = await _itemDialog('تعديل العنوان', initial: it);
                              if (n == null) return;
                              final updated = index.map((x) => identical(x, it) ? n : x).toList();
                              await BookIndex.save(widget.book, updated);
                              if (!mounted) return;
                              setState(() => index = updated);
                              setSheet(() {});
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async {
                              if (!await _confirmText('هل تريد حذف \"${it.title}\" من الفهرس؟')) return;
                              final updated = index.where((x) => !identical(x, it)).toList();
                              await BookIndex.save(widget.book, updated);
                              if (!mounted) return;
                              setState(() => index = updated);
                              setSheet(() {});
                            },
                          ),
                        ]),
                      );
                    },
                  ),
                ),
            ]),
          ),
        );
      }),
    );
  }

  Future<void> _goToDialog() async {
    final c = TextEditingController();
    final n = await showDialog<int>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('الانتقال إلى صفحة'),
        content: TextField(controller: c, keyboardType: TextInputType.number, autofocus: true, decoration: InputDecoration(hintText: '1 - $total')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, int.tryParse(c.text.trim())), child: const Text('انتقال')),
        ],
      ),
    );
    if (n != null && n >= 1 && n <= total) controller.goToPage(pageNumber: n);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      backgroundColor: dx(context).primary,
      foregroundColor: Colors.white,
      title: Text(widget.book.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16)),
      actions: [
        IconButton(
          tooltip: 'الفهرس',
          icon: Icon(Icons.format_list_numbered, color: index.isEmpty ? Colors.white : dx(context).highlight),
          onPressed: total == 0 ? null : _showIndex,
        ),
        IconButton(tooltip: 'إضافة علامة هنا', icon: const Icon(Icons.bookmark_add_outlined), onPressed: total == 0 ? null : _addMark),
        IconButton(
          tooltip: 'الملحوظات',
          icon: Icon(hls.isEmpty ? Icons.sticky_note_2_outlined : Icons.sticky_note_2, color: hls.isEmpty ? Colors.white : dx(context).highlight),
          onPressed: total == 0 ? null : _showNotes,
        ),
        IconButton(
          tooltip: 'كل العلامات',
          icon: Icon(marks.isEmpty ? Icons.bookmarks_outlined : Icons.bookmarks, color: marks.isEmpty ? Colors.white : dx(context).highlight),
          onPressed: total == 0 ? null : _showMarks,
        ),
      ],
    ),
    body: Column(children: [
      Expanded(child: Listener(behavior: HitTestBehavior.translucent, onPointerDown: _onDown, onPointerMove: _onMove, onPointerUp: _onUp, onPointerCancel: _onUp, child: _wrapMode(PdfViewer.asset(
        widget.book.asset,
        key: _viewerKey,
        controller: controller,
        params: PdfViewerParams(
          backgroundColor: const Color(0xFFD9D4CC),
          textSelectionParams: PdfTextSelectionParams(enabled: false),
          interactionEndFrictionCoefficient: 0.008,
          layoutPages: normalizedLayout,
          panEnabled: !hlMode,
          scaleEnabled: !hlMode,
          pagePaintCallbacks: [_paintHl],
          viewerOverlayBuilder: (context, size, handleLinkTap) => [
            if (thumbVisible) PdfViewerScrollThumb(
              controller: controller,
              orientation: ScrollbarOrientation.right,
              thumbSize: const Size(52, 36),
              thumbBuilder: (context, thumbSize, pageNumber, ctrl) => Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: burgundy,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: gold, width: 1.5),
                  boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4)],
                ),
                child: Text(pageNumber == null ? '' : ar(pageNumber), style: const TextStyle(color: gold, fontWeight: FontWeight.bold, fontSize: 14)),
              ),
            ),
          ],
          onPageChanged: (p) {
            if (p != null && mounted) setState(() => page = p);
          },
          onViewerReady: (document, ctrl) async {
            final list = await Bookmarks.load(widget.book);
            final idx = await BookIndex.load(widget.book);
            final off = await BookIndex.loadOffset(widget.book);
            final hlList = await HlStore.load(widget.book);
            if (!mounted) return;
            final count = document.pages.length;
            setState(() {
              total = count;
              marks = list;
              index = idx;
              offset = off;
              hls = hlList;
              _doc = document;
            });
            if (list.isNotEmpty) {
              final last = list.reduce((a, b) => a.t >= b.t ? a : b);
              if (last.page > 1 && last.page <= count) {
                ctrl.goToPage(pageNumber: last.page);
                _snack('تم الانتقال إلى آخر علامة: ${last.name}');
              }
            }
          },
        ),
      )))),
      Container(
        color: dx(context).primary,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        child: SafeArea(
          top: false,
          child: hlMode ? _hlBar() : Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            ValueListenableBuilder<int>(valueListenable: AppPrefs.eye, builder: (context, m, _) => IconButton(color: Colors.white, tooltip: 'وضع راحة العين', icon: Icon(eyeModes[m].icon), onPressed: () => showEyeModeSheet(context))),
            IconButton(color: Colors.white, onPressed: page > 1 ? () => controller.goToPage(pageNumber: page - 1, duration: const Duration(milliseconds: 80)) : null, icon: const Icon(Icons.keyboard_arrow_up)),
            InkWell(
              onTap: total == 0 ? null : _goToDialog,
              borderRadius: BorderRadius.circular(10),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                child: Text(total == 0 ? '...' : '${ar(page)} / ${ar(total)}', style: TextStyle(color: dx(context).highlight, fontWeight: FontWeight.bold, fontSize: 16)),
              ),
            ),
            IconButton(color: Colors.white, onPressed: total > 0 && page < total ? () => controller.goToPage(pageNumber: page + 1, duration: const Duration(milliseconds: 80)) : null, icon: const Icon(Icons.keyboard_arrow_down)),
            const SizedBox(width: 48),
          ]),
        ),
      ),
    ]),
  );
}

class MorePage extends StatelessWidget {
  final bool dark;
  final ValueChanged<bool> onThemeChanged;
  const MorePage({super.key, required this.dark, required this.onThemeChanged});
  @override
  Widget build(BuildContext context) => ListView(children: [
    ListTile(
      leading: const Icon(Icons.history),
      title: const Text('سجل القراءة'),
      subtitle: const Text('الوقت الذي قضيتَه في كل قسم وكتاب'),
      trailing: const Icon(Icons.chevron_left),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const UsageLogPage())),
    ),
    ListTile(
      leading: const Icon(Icons.palette_outlined),
      title: const Text('التصميم'),
      subtitle: ValueListenableBuilder<int>(valueListenable: AppPrefs.design, builder: (context, d, _) => Text('الحالي: ${designSpecs[d].name}')),
      trailing: const Icon(Icons.chevron_left),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DesignPage())),
    ),
    ListTile(
      leading: const Icon(Icons.visibility_outlined),
      title: const Text('وضع راحة العين'),
      subtitle: ValueListenableBuilder<int>(valueListenable: AppPrefs.eye, builder: (context, m, _) => Text('الحالي: ${eyeModes[m].name}')),
      trailing: const Icon(Icons.chevron_left),
      onTap: () => showEyeModeSheet(context),
    ),
    SwitchListTile(
      secondary: const Icon(Icons.dark_mode_outlined),
      title: const Text('الوضع الداكن'),
      value: dark,
      onChanged: onThemeChanged,
    ),
    const ListTile(leading: Icon(Icons.info_outline), title: Text('عن التطبيق'), subtitle: Text('ميراث النبوة — مكتبة علمية للقراءة دون اتصال بالإنترنت.')),
    const ListTile(leading: Icon(Icons.library_books_outlined), title: Text('إصدار التطبيق'), subtitle: Text('1.2.0')),
  ]);
}

PdfPageLayout normalizedLayout(List<PdfPage> pages, PdfViewerParams params) {
  final widths = pages.map((x) => x.width).toList()..sort();
  final w = widths[widths.length ~/ 2];
  final rects = <Rect>[];
  var y = params.margin;
  for (final pg in pages) {
    final h = pg.width <= 0 ? pg.height : pg.height * w / pg.width;
    rects.add(Rect.fromLTWH(params.margin, y, w, h));
    y += h + params.margin;
  }
  return PdfPageLayout(pageLayouts: rects, documentSize: Size(w + params.margin * 2, y));
}

String fmtClock(int s) {
  String two(int n) => n.toString().padLeft(2, '0');
  final t = '${two(s ~/ 3600)}:${two((s % 3600) ~/ 60)}:${two(s % 60)}';
  return t.split('').map((ch) => ch == ':' ? ch : ar(int.parse(ch))).join();
}

String fmtDur(int s) {
  final h = s ~/ 3600;
  final m = (s % 3600) ~/ 60;
  final sec = s % 60;
  if (h > 0) return '${ar(h)} س ${ar(m)} د';
  if (m > 0) return '${ar(m)} د ${ar(sec)} ث';
  return '${ar(sec)} ث';
}

String sectionOf(Book b) {
  for (final c in libCategories) {
    if (booksFor(c.name).any((x) => x.asset == b.asset || x.parts.any((p) => p.asset == b.asset))) return c.name;
  }
  return 'المكتبة';
}

class Place {
  final String section;
  final String? book;
  const Place(this.section, [this.book]);
  String get key => book == null ? section : '$section|$book';
}

class UsageTracker {
  UsageTracker._();
  static final UsageTracker instance = UsageTracker._();

  final ValueNotifier<int> seconds = ValueNotifier<int>(0);
  Map<String, Map<String, int>> log = {};
  String base = 'الرئيسية';
  final List<Place> _stack = [];
  Timer? _timer;
  bool _started = false;
  bool _loaded = false;
  int _unsaved = 0;

  Place get current => _stack.isNotEmpty ? _stack.last : Place(base);
  Place enter(String section, [String? book]) {
    final p = Place(section, book);
    _stack.add(p);
    return p;
  }
  void leave(Place p) => _stack.removeWhere((x) => identical(x, p));

  String dayKey() {
    final n = DateTime.now();
    return '${n.year}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
  }
  int todaySeconds() => (log[dayKey()] ?? const <String, int>{}).values.fold<int>(0, (a, b) => a + b);

  Future<void> start() async {
    if (_started) return;
    _started = true;
    await _load();
    _loaded = true;
    resume();
  }
  void resume() {
    if (!_loaded || _timer != null) return;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }
  void pause() {
    _timer?.cancel();
    _timer = null;
    if (_loaded) _save();
  }
  void _tick() {
    seconds.value = seconds.value + 1;
    final day = log.putIfAbsent(dayKey(), () => <String, int>{});
    final k = current.key;
    day[k] = (day[k] ?? 0) + 1;
    _unsaved++;
    if (_unsaved >= 15) _save();
  }
  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getString('usage_log');
      if (raw == null) return;
      final m = jsonDecode(raw) as Map;
      final out = <String, Map<String, int>>{};
      m.forEach((d, v) {
        final inner = <String, int>{};
        (v as Map).forEach((k, s) {
          inner[k as String] = (s as num).toInt();
        });
        out[d as String] = inner;
      });
      log = out;
    } catch (_) {
      log = {};
    }
  }
  Future<void> _save() async {
    _unsaved = 0;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('usage_log', jsonEncode(log));
    } catch (_) {}
  }
  Future<void> clearLog() async {
    log = {};
    await _save();
  }
}

class BigTimer extends StatelessWidget {
  final int seconds;
  final Color color;
  final double size;
  const BigTimer({super.key, required this.seconds, required this.color, this.size = 76});
  @override
  Widget build(BuildContext context) {
    final s = fmtClock(seconds);
    return FittedBox(
      fit: BoxFit.scaleDown,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        textDirection: TextDirection.ltr,
        children: [
          for (final ch in s.split(''))
            SizedBox(
              width: ch == ':' ? size * 0.3 : size * 0.62,
              child: Text(
                ch,
                textAlign: TextAlign.center,
                softWrap: false,
                overflow: TextOverflow.visible,
                style: TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, fontSize: size, height: 1.2, color: color, shadows: const [Shadow(color: Color(0x33E4B83F), blurRadius: 14)]),
              ),
            ),
        ],
      ),
    );
  }
}

String _arTwo(int n) => '${ar(n ~/ 10)}${ar(n % 10)}';

class _RingPainter extends CustomPainter {
  final double progress;
  final Color color;
  final Color track;
  const _RingPainter({required this.progress, required this.color, required this.track});
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 10;
    final rect = Rect.fromCircle(center: c, radius: r);
    final base = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 9
      ..strokeCap = StrokeCap.round
      ..color = track;
    canvas.drawCircle(c, r, base);
    final tick = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..color = track;
    for (int i = 0; i < 60; i += 5) {
      final a = -math.pi / 2 + i * math.pi / 30;
      canvas.drawLine(
        Offset(c.dx + (r - 18) * math.cos(a), c.dy + (r - 18) * math.sin(a)),
        Offset(c.dx + (r - 26) * math.cos(a), c.dy + (r - 26) * math.sin(a)),
        tick,
      );
    }
    final arc = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 9
      ..strokeCap = StrokeCap.round
      ..color = color;
    canvas.drawArc(rect, -math.pi / 2, 2 * math.pi * progress, false, arc);
    final end = -math.pi / 2 + 2 * math.pi * progress;
    canvas.drawCircle(Offset(c.dx + r * math.cos(end), c.dy + r * math.sin(end)), 7, Paint()..color = color);
  }
  @override
  bool shouldRepaint(covariant _RingPainter old) => old.progress != progress || old.color != color || old.track != track;
}

class _UsageCounter extends StatelessWidget {
  final VoidCallback onTap;
  const _UsageCounter({required this.onTap});
  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 16),
        decoration: BoxDecoration(
          color: x.card,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: x.textAccent.withAlpha(80)),
          boxShadow: const [BoxShadow(color: Color(0x1F000000), blurRadius: 14, offset: Offset(0, 6))],
        ),
        child: Column(children: [
          Text('مدة جلستك في التطبيق', style: TextStyle(fontSize: 15, color: x.muted)),
          const SizedBox(height: 14),
          ValueListenableBuilder<int>(
            valueListenable: UsageTracker.instance.seconds,
            builder: (context, s, _) {
              final h = s ~/ 3600;
              final m = (s % 3600) ~/ 60;
              final sec = s % 60;
              return Column(children: [
                SizedBox(
                  width: 230,
                  height: 230,
                  child: CustomPaint(
                    painter: _RingPainter(progress: sec / 60, color: x.textAccent, track: x.textAccent.withAlpha(45)),
                    child: Center(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Text(
                          '${_arTwo(h)}:${_arTwo(m)}',
                          textDirection: TextDirection.ltr,
                          style: TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, fontSize: 50, height: 1.2, color: x.textAccent),
                        ),
                        Text('${_arTwo(sec)} ثانية', style: TextStyle(fontSize: 15, color: x.muted, fontWeight: FontWeight.w600)),
                      ]),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(color: x.textAccent.withAlpha(28), borderRadius: BorderRadius.circular(22)),
                  child: Text('إجمالي اليوم: ${fmtClock(UsageTracker.instance.todaySeconds())}', style: TextStyle(fontSize: 15, color: x.textAccent, fontWeight: FontWeight.w700)),
                ),
              ]);
            },
          ),
          const SizedBox(height: 12),
          Text('اضغط لعرض سجل القراءة', style: TextStyle(fontSize: 12.5, color: x.muted)),
        ]),
      ),
    );
  }
}

class UsageLogPage extends StatefulWidget {
  const UsageLogPage({super.key});
  @override
  State<UsageLogPage> createState() => _UsageLogPageState();
}
class _UsageLogPageState extends State<UsageLogPage> {
  Future<void> _clear() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('مسح السجل'),
        content: const Text('هل تريد مسح سجل القراءة بالكامل؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('مسح')),
        ],
      ),
    );
    if (ok != true) return;
    await UsageTracker.instance.clearLog();
    if (mounted) setState(() {});
  }

  String _dayLabel(String key) {
    final p = key.split('-');
    if (p.length != 3) return key;
    final txt = '${ar(int.parse(p[2]))}/${ar(int.parse(p[1]))}/${ar(int.parse(p[0]))}';
    return key == UsageTracker.instance.dayKey() ? 'اليوم - $txt' : txt;
  }

  Widget _entryTile(String key, int secs) {
    final i = key.indexOf('|');
    final section = i < 0 ? key : key.substring(0, i);
    final book = i < 0 ? null : key.substring(i + 1);
    return ListTile(
      dense: true,
      leading: Icon(book == null ? Icons.folder_open : Icons.menu_book, color: burgundy, size: 20),
      title: Text(book ?? section),
      subtitle: book == null ? null : Text(section),
      trailing: Text(fmtDur(secs), style: const TextStyle(fontWeight: FontWeight.bold, color: burgundy)),
    );
  }

  Widget _dayTile(String day, Map<String, int> items) {
    final total = items.values.fold<int>(0, (a, b) => a + b);
    final entries = items.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: ExpansionTile(
        key: PageStorageKey(day),
        shape: const Border(),
        collapsedShape: const Border(),
        leading: const CircleAvatar(backgroundColor: Color(0xFFFFF0C2), child: Icon(Icons.calendar_today, color: burgundy, size: 20)),
        title: Text(_dayLabel(day), style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('المدة: ${fmtDur(total)}'),
        children: [for (final e in entries) _entryTile(e.key, e.value)],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = UsageTracker.instance;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: dx(context).primary,
        foregroundColor: dx(context).highlight,
        title: const Text('سجل القراءة', style: TextStyle(fontFamily: kDeco, fontWeight: FontWeight.w700, fontSize: 24)),
        actions: [IconButton(tooltip: 'مسح السجل', icon: const Icon(Icons.delete_outline), onPressed: _clear)],
      ),
      body: ValueListenableBuilder<int>(
        valueListenable: t.seconds,
        builder: (context, _, __) {
          final days = t.log.keys.toList()..sort((a, b) => b.compareTo(a));
          if (days.isEmpty) return const Center(child: Text('لا يوجد سجل بعد.'));
          final all = t.log.values.fold<int>(0, (s, d) => s + d.values.fold<int>(0, (x, y) => x + y));
          return ListView(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 28),
            children: [
              Container(
                margin: const EdgeInsets.only(bottom: 14),
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [burgundy, Color(0xFF8B344B)]),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(children: [
                  const Icon(Icons.timer_outlined, color: gold, size: 34),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('إجمالي الوقت في التطبيق', style: TextStyle(color: Colors.white70, fontSize: 13.5)),
                      Text(fmtDur(all), style: const TextStyle(color: gold, fontSize: 22, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                ]),
              ),
              for (final d in days) _dayTile(d, t.log[d]!),
            ],
          );
        },
      ),
    );
  }
}
