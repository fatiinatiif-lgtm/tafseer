import 'dart:convert';
import 'dart:io';
import 'package:file_saver/file_saver.dart';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'designs.dart';
import 'main.dart';
import 'notes_export.dart';

// ════════════════════════════════════════════════════════════
//  الملاحظات المحفوظة (صورة أو PDF) من كل الكتب
// ════════════════════════════════════════════════════════════

class SavedNote {
  final int id;
  final String bookTitle;
  final String bookAsset;
  final int page;
  final int color;
  final bool isPdf;
  final String file; // اسم الملف داخل مجلد الملاحظات
  final String thumb; // اسم صورة المعاينة (قد يكون فارغًا)
  final String note;
  const SavedNote(this.id, this.bookTitle, this.bookAsset, this.page, this.color, this.isPdf, this.file, this.thumb, this.note);

  Map<String, dynamic> toJson() => {
        'i': id,
        'bt': bookTitle,
        'ba': bookAsset,
        'p': page,
        'c': color,
        'pdf': isPdf,
        'f': file,
        't': thumb,
        'n': note,
      };

  static SavedNote fromJson(Map<String, dynamic> j) => SavedNote(
        j['i'] as int,
        (j['bt'] as String?) ?? '',
        (j['ba'] as String?) ?? '',
        (j['p'] as int?) ?? 1,
        ((j['c'] as int?) ?? 0).clamp(0, hlColors.length - 1).toInt(),
        (j['pdf'] as bool?) ?? false,
        (j['f'] as String?) ?? '',
        (j['t'] as String?) ?? '',
        (j['n'] as String?) ?? '',
      );
}

class SavedNotes {
  static const _k = 'saved_notes_v1';
  static String _dirPath = '';
  // يزيد كلما تغيرت الملاحظات ليتحدث قسم «الملاحظات» تلقائيًا
  static final ValueNotifier<int> version = ValueNotifier<int>(0);

  static Future<Directory> dir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/saved_notes');
    if (!await d.exists()) await d.create(recursive: true);
    _dirPath = d.path;
    return d;
  }

  static String pathOf(SavedNote n) => '$_dirPath/${n.file}';
  static String thumbPathOf(SavedNote n) => '$_dirPath/${n.thumb}';

  static Future<List<SavedNote>> load() async {
    await dir();
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_k);
    if (raw == null) return <SavedNote>[];
    try {
      final list = jsonDecode(raw) as List;
      final items = list.map((e) => SavedNote.fromJson(Map<String, dynamic>.from(e as Map))).where((n) => n.file.isNotEmpty).toList();
      items.sort((a, b) => b.id.compareTo(a.id));
      return items;
    } catch (_) {
      return <SavedNote>[];
    }
  }

  static Future<void> _write(List<SavedNote> items) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_k, jsonEncode(items.map((n) => n.toJson()).toList()));
    version.value++;
  }

  /// ينشئ الصورة أو ملف PDF للتلوين ويحفظه في قسم الملاحظات.
  static Future<SavedNote?> create({
    required Book book,
    required Hl h,
    required PdfDocument doc,
    required bool pdf,
    required String note,
  }) async {
    final d = await dir();
    final id = DateTime.now().millisecondsSinceEpoch;
    final jpg = await cropHlImage(doc, h);
    if (jpg == null && !pdf) return null;
    var thumbName = '';
    if (jpg != null) {
      thumbName = 'n$id.jpg';
      await File('${d.path}/$thumbName').writeAsBytes(jpg);
    }
    var fileName = thumbName;
    if (pdf) {
      fileName = 'n$id.pdf';
      await buildNotesPdf(book, [h.withNote(note)], doc, outDir: d, fileName: fileName);
    }
    final n = SavedNote(id, book.title, book.asset, h.page, h.color, pdf, fileName, thumbName, note);
    final items = await load();
    await _write([n, ...items]);
    return n;
  }

  static Future<void> remove(SavedNote n) async {
    for (final name in {n.file, n.thumb}) {
      if (name.isEmpty) continue;
      try {
        final f = File('$_dirPath/$name');
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
    final items = await load();
    await _write(items.where((x) => x.id != n.id).toList());
  }

  static Future<void> share(SavedNote n) async {
    final text = n.note.isEmpty ? '${n.bookTitle} · صفحة ${ar(n.page)}' : n.note;
    await Share.shareXFiles([XFile(pathOf(n), mimeType: n.isPdf ? 'application/pdf' : 'image/jpeg')], text: text);
  }

  /// يحفظ على الموبايل: الصورة في معرض الصور، والـ PDF في المكان الذي تختاره. يرجع رسالة للعرض (أو null لو أُلغي).
  static Future<String?> saveToPhone(SavedNote n) async {
    final f = File(pathOf(n));
    if (!await f.exists()) return 'الملف غير موجود';
    if (!n.isPdf) {
      try {
        if (!await Gal.hasAccess()) {
          if (!await Gal.requestAccess()) return 'لم يتم السماح بحفظ الصور على الجهاز';
        }
        await Gal.putImage(f.path, album: 'كتب التفاسير');
        return 'تم حفظ الصورة في معرض الصور';
      } catch (_) {
        return 'تعذّر حفظ الصورة';
      }
    }
    try {
      final bytes = await f.readAsBytes();
      final saved = await FileSaver.instance.saveAs(name: 'note_${n.id}', bytes: bytes, ext: 'pdf', mimeType: MimeType.pdf);
      if (saved == null || saved.isEmpty) return null;
      return 'تم حفظ ملف PDF';
    } catch (_) {
      return 'تعذّر حفظ الملف';
    }
  }
}

String _fmtDate(int ms) {
  final d = DateTime.fromMillisecondsSinceEpoch(ms);
  return '${ar(d.day)} / ${ar(d.month)} / ${ar(d.year)}';
}

void _toast(BuildContext context, String text) {
  final m = ScaffoldMessenger.of(context);
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(content: Text(text), duration: const Duration(seconds: 2)));
}

Future<void> _saveToPhoneWithToast(BuildContext context, SavedNote n) async {
  final msg = await SavedNotes.saveToPhone(n);
  if (msg != null && context.mounted) _toast(context, msg);
}

Future<bool> _confirmDelete(BuildContext context) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      content: const Text('هل تريد حذف هذه الملحوظة؟'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
      ],
    ),
  );
  return r ?? false;
}

// ───────────── نافذة اختيار «حفظ كـ» بعد التلوين ─────────────

Future<SavedNote?> showSaveNoteSheet(BuildContext context, Book book, Hl h, PdfDocument doc) {
  return showModalBottomSheet<SavedNote>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (ctx) => _SaveNoteSheet(book: book, hl: h, doc: doc),
  );
}

class _SaveNoteSheet extends StatefulWidget {
  final Book book;
  final Hl hl;
  final PdfDocument doc;
  const _SaveNoteSheet({required this.book, required this.hl, required this.doc});
  @override
  State<_SaveNoteSheet> createState() => _SaveNoteSheetState();
}

class _SaveNoteSheetState extends State<_SaveNoteSheet> {
  final ctl = TextEditingController();
  bool busy = false;
  String? err;

  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }

  Future<void> _go(bool pdf) async {
    setState(() {
      busy = true;
      err = null;
    });
    try {
      final n = await SavedNotes.create(book: widget.book, h: widget.hl, doc: widget.doc, pdf: pdf, note: ctl.text.trim());
      if (!mounted) return;
      if (n == null) {
        setState(() {
          busy = false;
          err = 'تعذّر تجهيز الصورة، حاول مرة أخرى';
        });
        return;
      }
      Navigator.pop(context, n);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        busy = false;
        err = 'تعذّر الحفظ، حاول مرة أخرى';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Container(width: 18, height: 18, decoration: BoxDecoration(color: hlColors[widget.hl.color], shape: BoxShape.circle)),
            const SizedBox(width: 8),
            Expanded(child: Text('حفظ الملحوظة · صفحة ${ar(widget.hl.page)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
          ]),
          const SizedBox(height: 12),
          TextField(
            controller: ctl,
            enabled: !busy,
            minLines: 2,
            maxLines: 5,
            decoration: const InputDecoration(hintText: 'اكتب ملاحظتك (اختياري)...', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 14),
          if (busy)
            const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Center(child: CircularProgressIndicator()))
          else ...[
            const Text('احفظها كـ:', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: FilledButton.icon(onPressed: () => _go(false), icon: const Icon(Icons.image_outlined), label: const Text('صورة')),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(onPressed: () => _go(true), icon: const Icon(Icons.picture_as_pdf_outlined), label: const Text('PDF')),
              ),
            ]),
            const SizedBox(height: 6),
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('تخطي (يبقى التلوين فقط)')),
          ],
          if (err != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(err!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.red))),
        ]),
      ),
    );
  }
}

// ───────────── صورة معاينة الملحوظة ─────────────

Widget _noteImage(SavedNote n, {BoxFit fit = BoxFit.cover, double? width, double? height}) {
  Widget fallback() => Container(
        width: width,
        height: height,
        color: Colors.black12,
        alignment: Alignment.center,
        child: Icon(n.isPdf ? Icons.picture_as_pdf : Icons.image_outlined, size: 36, color: Colors.black45),
      );
  if (n.thumb.isEmpty) return fallback();
  return Image.file(
    File(SavedNotes.thumbPathOf(n)),
    fit: fit,
    width: width,
    height: height,
    alignment: Alignment.topCenter,
    cacheWidth: 700,
    errorBuilder: (_, __, ___) => fallback(),
  );
}

Widget _typeBadge(SavedNote n) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(color: n.isPdf ? const Color(0xFFC62828) : const Color(0xFF1B4F9C), borderRadius: BorderRadius.circular(8)),
      child: Text(n.isPdf ? 'PDF' : 'صورة', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
    );

// ───────────── قسم «الملاحظات» أعلى الكتب ─────────────

class NotesSection extends StatefulWidget {
  const NotesSection({super.key});
  @override
  State<NotesSection> createState() => _NotesSectionState();
}

class _NotesSectionState extends State<NotesSection> {
  List<SavedNote> items = [];

  @override
  void initState() {
    super.initState();
    _load();
    SavedNotes.version.addListener(_load);
  }

  @override
  void dispose() {
    SavedNotes.version.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final l = await SavedNotes.load();
    if (mounted) setState(() => items = l);
  }

  void _openAll() => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotesPage()));

  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
      decoration: BoxDecoration(color: x.card, borderRadius: BorderRadius.circular(18), border: Border.all(color: x.textAccent.withAlpha(90))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Icon(Icons.edit_note, color: x.textAccent, size: 32),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('الملاحظات', style: TextStyle(color: x.ink, fontWeight: FontWeight.w800, fontSize: 18)),
              Text(items.isEmpty ? 'ما حفظتَه من الكتب يظهر هنا.' : '${ar(items.length)} محفوظة', style: TextStyle(color: x.muted, fontSize: 12.5)),
            ]),
          ),
          if (items.isNotEmpty) TextButton(onPressed: _openAll, child: const Text('عرض الكل')),
        ]),
        if (items.isEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(0, 10, 6, 4),
            child: Text('اضغط مطوّلًا على أي صفحة في الكتاب لتلوين فقرة، ثم اختر حفظها كصورة أو PDF.', style: TextStyle(color: x.muted, fontSize: 13, height: 1.6)),
          )
        else
          Padding(
            padding: const EdgeInsets.only(top: 10, left: 6),
            child: SizedBox(
              height: 130,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: items.length > 12 ? 12 : items.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (c, i) {
                  final n = items[i];
                  return GestureDetector(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SavedNoteViewPage(note: n))),
                    child: Container(
                      width: 104,
                      decoration: BoxDecoration(border: Border.all(color: hlColors[n.color], width: 2.5), borderRadius: BorderRadius.circular(10)),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(7.5),
                        child: Stack(fit: StackFit.expand, children: [
                          _noteImage(n),
                          Positioned(top: 4, right: 4, child: _typeBadge(n)),
                          Positioned(
                            left: 0,
                            right: 0,
                            bottom: 0,
                            child: Container(
                              color: Colors.black54,
                              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                              child: Text('صفحة ${ar(n.page)}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 11)),
                            ),
                          ),
                        ]),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
      ]),
    );
  }
}

// ───────────── صفحة كل الملاحظات ─────────────

class NotesPage extends StatefulWidget {
  const NotesPage({super.key});
  @override
  State<NotesPage> createState() => _NotesPageState();
}

class _NotesPageState extends State<NotesPage> {
  List<SavedNote> items = [];
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await SavedNotes.load();
    if (mounted) {
      setState(() {
        items = l;
        loaded = true;
      });
    }
  }

  Future<void> _delete(SavedNote n) async {
    if (!await _confirmDelete(context)) return;
    await SavedNotes.remove(n);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    return Scaffold(
      backgroundColor: x.bg,
      appBar: AppBar(
        title: Text('الملاحظات (${ar(items.length)})'),
        backgroundColor: x.primary,
        foregroundColor: Colors.white,
      ),
      body: !loaded
          ? const Center(child: CircularProgressIndicator())
          : items.isEmpty
              ? Center(child: Padding(padding: const EdgeInsets.all(30), child: Text('لا توجد ملاحظات محفوظة بعد.', style: TextStyle(color: x.muted))))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 30),
                  itemCount: items.length,
                  itemBuilder: (c, i) {
                    final n = items[i];
                    return Card(
                      color: x.card,
                      margin: const EdgeInsets.only(bottom: 14),
                      clipBehavior: Clip.antiAlias,
                      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
                          child: Row(children: [
                            Container(width: 14, height: 14, decoration: BoxDecoration(color: hlColors[n.color], shape: BoxShape.circle)),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(n.bookTitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: x.ink, fontWeight: FontWeight.bold)),
                                Text('صفحة ${ar(n.page)} · ${_fmtDate(n.id)}', style: TextStyle(color: x.muted, fontSize: 12)),
                              ]),
                            ),
                            const SizedBox(width: 8),
                            _typeBadge(n),
                          ]),
                        ),
                        InkWell(
                          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SavedNoteViewPage(note: n))),
                          child: ConstrainedBox(
                            constraints: const BoxConstraints(maxHeight: 240),
                            child: _noteImage(n, fit: BoxFit.fitWidth, width: double.infinity),
                          ),
                        ),
                        if (n.note.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
                            child: Text(n.note, style: TextStyle(color: x.ink, fontSize: 15, height: 1.6)),
                          ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(6, 4, 6, 4),
                          child: Wrap(alignment: WrapAlignment.start, children: [
                            TextButton.icon(onPressed: () => SavedNotes.share(n), icon: const Icon(Icons.share_outlined, size: 20), label: const Text('مشاركة')),
                            TextButton.icon(onPressed: () => _saveToPhoneWithToast(context, n), icon: const Icon(Icons.download_outlined, size: 20), label: const Text('حفظ في الموبايل')),
                            IconButton(tooltip: 'حذف', onPressed: () => _delete(n), icon: const Icon(Icons.delete_outline)),
                          ]),
                        ),
                      ]),
                    );
                  },
                ),
    );
  }
}

// ───────────── عرض ملحوظة واحدة (صورة أو PDF) ─────────────

class SavedNoteViewPage extends StatelessWidget {
  final SavedNote note;
  const SavedNoteViewPage({super.key, required this.note});

  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    final n = note;
    return Scaffold(
      backgroundColor: x.bg,
      appBar: AppBar(
        title: Text('صفحة ${ar(n.page)}'),
        backgroundColor: x.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(tooltip: 'مشاركة', icon: const Icon(Icons.share_outlined), onPressed: () => SavedNotes.share(n)),
          IconButton(tooltip: 'حفظ في الموبايل', icon: const Icon(Icons.download_outlined), onPressed: () => _saveToPhoneWithToast(context, n)),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: n.isPdf
              ? PdfViewer.file(SavedNotes.pathOf(n))
              : InteractiveViewer(
                  minScale: 1,
                  maxScale: 5,
                  child: Center(child: _noteImage(n, fit: BoxFit.contain)),
                ),
        ),
        if (n.note.isNotEmpty)
          Container(
            width: double.infinity,
            color: x.card,
            padding: const EdgeInsets.all(14),
            child: SafeArea(top: false, child: Text(n.note, style: TextStyle(color: x.ink, fontSize: 15, height: 1.6))),
          ),
      ]),
    );
  }
}
