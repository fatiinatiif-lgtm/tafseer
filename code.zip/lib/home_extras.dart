import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'designs.dart';
import 'goals.dart';
import 'main.dart';

// ════════════════════════════════════════════════════════════
//  إضافات الشاشة الرئيسية: كمّل القراءة + أهداف اليوم
// ════════════════════════════════════════════════════════════

class LastReadInfo {
  final String asset;
  final String title;
  final int page;
  final int total;
  final int ts;
  const LastReadInfo(this.asset, this.title, this.page, this.total, this.ts);
}

class LastRead {
  static const _k = 'last_read_v1';
  static final ValueNotifier<int> version = ValueNotifier<int>(0);

  static Future<void> save(Book b, int page, int total) async {
    if (page < 1) return;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString(_k, jsonEncode({'a': b.asset, 't': b.title, 'p': page, 'n': total, 'ts': DateTime.now().millisecondsSinceEpoch}));
      version.value++;
    } catch (_) {}
  }

  static Future<LastReadInfo?> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final raw = p.getString(_k);
      if (raw == null) return null;
      final j = jsonDecode(raw) as Map<String, dynamic>;
      return LastReadInfo(j['a'] as String, j['t'] as String, (j['p'] as int?) ?? 1, (j['n'] as int?) ?? 0, (j['ts'] as int?) ?? 0);
    } catch (_) {
      return null;
    }
  }
}

Book? findBookByAsset(String asset) {
  for (final b in allBooks) {
    for (final part in b.parts) {
      if (part.asset == asset) return part;
    }
  }
  for (final b in allBooks) {
    if (!b.isMulti && b.asset == asset) return b;
  }
  return null;
}

// ───────────── كمّل القراءة ─────────────

class ContinueReadingCard extends StatefulWidget {
  const ContinueReadingCard({super.key});
  @override
  State<ContinueReadingCard> createState() => _ContinueReadingCardState();
}

class _ContinueReadingCardState extends State<ContinueReadingCard> {
  LastReadInfo? info;

  @override
  void initState() {
    super.initState();
    _load();
    LastRead.version.addListener(_load);
  }

  @override
  void dispose() {
    LastRead.version.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final i = await LastRead.load();
    if (mounted) setState(() => info = i);
  }

  Future<void> _open() async {
    final i = info;
    if (i == null) return;
    final b = findBookByAsset(i.asset);
    if (b == null) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => PdfReaderPage(book: b, initialPage: i.page)));
  }

  @override
  Widget build(BuildContext context) {
    final i = info;
    if (i == null || findBookByAsset(i.asset) == null) return const SizedBox.shrink();
    final x = dx(context);
    final frac = i.total > 0 ? (i.page / i.total).clamp(0.0, 1.0).toDouble() : 0.0;
    return Padding(
      padding: const EdgeInsets.only(top: 14),
      child: Material(
        color: x.card,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: _open,
          child: Container(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: x.textAccent.withAlpha(90))),
            child: Row(children: [
              Icon(Icons.auto_stories, color: x.textAccent, size: 34),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('كمّل القراءة', style: TextStyle(color: x.muted, fontSize: 12.5)),
                  Text(i.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: x.ink, fontWeight: FontWeight.w800, fontSize: 16, height: 1.4)),
                  const SizedBox(height: 6),
                  Text(i.total > 0 ? 'صفحة ${ar(i.page)} من ${ar(i.total)}' : 'صفحة ${ar(i.page)}', style: TextStyle(color: x.muted, fontSize: 12.5)),
                  if (i.total > 0) ...[
                    const SizedBox(height: 6),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(value: frac, minHeight: 6, color: x.highlight, backgroundColor: x.textAccent.withAlpha(40)),
                    ),
                  ],
                ]),
              ),
              const SizedBox(width: 8),
              Icon(Icons.play_circle_fill, color: x.highlight, size: 38),
            ]),
          ),
        ),
      ),
    );
  }
}

// ───────────── أهداف اليوم ─────────────

class GoalsProgressCard extends StatefulWidget {
  final VoidCallback onTap;
  const GoalsProgressCard({super.key, required this.onTap});
  @override
  State<GoalsProgressCard> createState() => _GoalsProgressCardState();
}

class _GoalsProgressCardState extends State<GoalsProgressCard> {
  GoalRecord? rec;

  @override
  void initState() {
    super.initState();
    _load();
    GoalsStore.version.addListener(_load);
  }

  @override
  void dispose() {
    GoalsStore.version.removeListener(_load);
    super.dispose();
  }

  Future<void> _load() async {
    final r = await GoalsStore.loadDay(GoalsClock.currentDay());
    if (mounted) setState(() => rec = r);
  }

  @override
  Widget build(BuildContext context) {
    final r = rec;
    if (r == null) return const SizedBox.shrink();
    final x = dx(context);
    final items = <List<Object>>[
      [Icons.menu_book, 'التفسير', r.tafsir],
      [Icons.auto_stories, 'القرآن', r.hizb],
      [Icons.local_library_outlined, 'البخاري', r.bukhari],
      [Icons.favorite_border, 'الصلاة', r.salawat],
    ];
    return Padding(
      padding: const EdgeInsets.only(top: 14),
      child: Material(
        color: x.card,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: widget.onTap,
          child: Container(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: x.textAccent.withAlpha(90))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Row(children: [
                Icon(Icons.fact_check_outlined, color: x.textAccent, size: 28),
                const SizedBox(width: 10),
                Expanded(child: Text('أهداف اليوم', style: TextStyle(color: x.ink, fontWeight: FontWeight.w800, fontSize: 17))),
                Text(r.all ? 'أتممتَ أهداف اليوم، ما شاء الله' : '${ar(r.doneCount)} من ${ar(4)}', style: TextStyle(color: r.all ? x.highlight : x.muted, fontWeight: FontWeight.bold, fontSize: 13)),
              ]),
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(value: r.doneCount / 4, minHeight: 7, color: x.highlight, backgroundColor: x.textAccent.withAlpha(40)),
              ),
              const SizedBox(height: 10),
              Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                for (final it in items)
                  Column(children: [
                    Icon((it[2] as bool) ? Icons.check_circle : it[0] as IconData, size: 24, color: (it[2] as bool) ? const Color(0xFF2E9E5B) : x.muted),
                    const SizedBox(height: 2),
                    Text(it[1] as String, style: TextStyle(fontSize: 11.5, color: (it[2] as bool) ? const Color(0xFF2E9E5B) : x.muted)),
                  ]),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}
