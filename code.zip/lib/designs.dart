import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart';

// ════════════════════════════════════════════════════════════
//  نظام التصاميم
// ════════════════════════════════════════════════════════════

class DesignSpec {
  final int id;
  final String name;
  final String desc;
  final IconData icon;
  final Color seed;
  final Color primary;
  final Color highlight;
  final Color bg;
  final Color card;
  final Color ink;
  final Color textAccent;
  final bool alwaysDark;
  const DesignSpec({
    required this.id,
    required this.name,
    required this.desc,
    required this.icon,
    required this.seed,
    required this.primary,
    required this.highlight,
    required this.bg,
    required this.card,
    required this.ink,
    required this.textAccent,
    this.alwaysDark = false,
  });
}

const designSpecs = <DesignSpec>[
  DesignSpec(
    id: 6,
    name: 'الأزرق والبرتقالي',
    desc: 'أزرق ملكي هادئ مع لمسات برتقالية دافئة',
    icon: Icons.auto_awesome,
    seed: Color(0xFF123F7A),
    primary: Color(0xFF123F7A),
    highlight: Color(0xFFF28C28),
    bg: Color(0xFFF2F6FC),
    card: Color(0xFFFFFFFF),
    ink: Color(0xFF0F2238),
    textAccent: Color(0xFF1B4F9C),
  ),
];

class DesignExt extends ThemeExtension<DesignExt> {
  final int id;
  final bool dark;
  final Color primary;
  final Color highlight;
  final Color bg;
  final Color card;
  final Color ink;
  final Color muted;
  final Color textAccent;
  const DesignExt({
    required this.id,
    required this.dark,
    required this.primary,
    required this.highlight,
    required this.bg,
    required this.card,
    required this.ink,
    required this.muted,
    required this.textAccent,
  });

  static DesignExt make(DesignSpec s, bool dark) {
    if (s.alwaysDark) {
      return DesignExt(id: s.id, dark: true, primary: s.primary, highlight: s.highlight, bg: s.bg, card: s.card, ink: s.ink, muted: const Color(0x99FFFFFF), textAccent: s.textAccent);
    }
    if (!dark) {
      return DesignExt(id: s.id, dark: false, primary: s.primary, highlight: s.highlight, bg: s.bg, card: s.card, ink: s.ink, muted: s.ink.withAlpha(158), textAccent: s.textAccent);
    }
    return DesignExt(
      id: s.id,
      dark: true,
      primary: s.primary,
      highlight: s.highlight,
      bg: Color.lerp(Colors.black, s.primary, 0.16)!,
      card: Color.lerp(Colors.black, s.primary, 0.30)!,
      ink: const Color(0xFFF1ECE6),
      muted: const Color(0x99FFFFFF),
      textAccent: s.highlight,
    );
  }

  @override
  DesignExt copyWith() => this;

  @override
  DesignExt lerp(ThemeExtension<DesignExt>? other, double t) {
    if (other is! DesignExt) return this;
    return t < 0.5 ? this : other;
  }
}

DesignExt dx(BuildContext c) => Theme.of(c).extension<DesignExt>() ?? DesignExt.make(designSpecs[0], isDarkCtx(c));

// ════════════════════════════════════════════════════════════
//  وضع راحة العين
// ════════════════════════════════════════════════════════════

class EyeMode {
  final String name;
  final String sub;
  final IconData icon;
  final Color bg;
  final Color ink;
  final ColorFilter? filter;
  const EyeMode(this.name, this.sub, this.icon, this.bg, this.ink, this.filter);
}

const eyeModes = <EyeMode>[
  EyeMode('عادي', 'ألوان الكتاب الأصلية', Icons.wb_sunny_outlined, Color(0xFFFFFFFF), Color(0xFF222222), null),
  EyeMode('ورقي مريح', 'خلفية كريمية دافئة تخفف سطوع الأبيض', Icons.menu_book_outlined, Color(0xFFF4E6C8), Color(0xFF3A2E1E), ColorFilter.mode(Color(0xFFF4E6C8), BlendMode.multiply)),
  EyeMode(
    'ليلي',
    'خلفية داكنة وكتابة فاتحة دافئة للقراءة في الظلام',
    Icons.nightlight_round,
    Color(0xFF151311),
    Color(0xFFE1D2B9),
    ColorFilter.matrix(<double>[
      -0.80, 0, 0, 0, 225,
      0, -0.75, 0, 0, 210,
      0, 0, -0.66, 0, 185,
      0, 0, 0, 1, 0,
    ]),
  ),
  EyeMode('أخضر هادئ', 'درجة خضراء ناعمة تريح العين في القراءة الطويلة', Icons.eco_outlined, Color(0xFFD5E8CF), Color(0xFF22331E), ColorFilter.mode(Color(0xFFD5E8CF), BlendMode.multiply)),
  EyeMode('كهرماني دافئ', 'يقلل الضوء الأزرق ويناسب القراءة مساءً', Icons.wb_twilight, Color(0xFFFFE2B0), Color(0xFF4A3414), ColorFilter.mode(Color(0xFFFFE2B0), BlendMode.multiply)),
  EyeMode(
    'رمادي هادئ',
    'تدرّج رمادي خفيف يخفف تشبّع الألوان',
    Icons.contrast,
    Color(0xFFEBEBEB),
    Color(0xFF2A2A2A),
    ColorFilter.matrix(<double>[
      0.196, 0.658, 0.066, 0, 0,
      0.196, 0.658, 0.066, 0, 0,
      0.196, 0.658, 0.066, 0, 0,
      0, 0, 0, 1, 0,
    ]),
  ),
  EyeMode(
    'ليلي كهرماني',
    'خلفية سوداء وكتابة كهرمانية بلا ضوء أزرق، للنوم القريب',
    Icons.bedtime_outlined,
    Color(0xFF1A0C05),
    Color(0xFFCDAA78),
    ColorFilter.matrix(<double>[
      -0.70, 0, 0, 0, 205,
      0, -0.62, 0, 0, 170,
      0, 0, -0.45, 0, 120,
      0, 0, 0, 1, 0,
    ]),
  ),
];

ColorFilter? eyeFilter(int mode) {
  if (mode < 0 || mode >= eyeModes.length) return null;
  return eyeModes[mode].filter;
}

class AppPrefs {
  static final ValueNotifier<int> eye = ValueNotifier<int>(0);
  static final ValueNotifier<bool> eyeAppWide = ValueNotifier<bool>(false);
  static bool _loaded = false;

  static Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final p = await SharedPreferences.getInstance();
      final e = p.getInt('read_mode') ?? 0;
      eye.value = (e >= 0 && e < eyeModes.length) ? e : 0;
      eyeAppWide.value = p.getBool('eye_app_wide') ?? false;
    } catch (_) {}
  }

  static Future<void> setEye(int v) async {
    eye.value = v;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setInt('read_mode', v);
    } catch (_) {}
  }

  static Future<void> setAppWide(bool v) async {
    eyeAppWide.value = v;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setBool('eye_app_wide', v);
    } catch (_) {}
  }
}

Widget _eyeTile(BuildContext ctx, DesignExt x, int i, int cur) {
  final e = eyeModes[i];
  return ListTile(
    leading: Container(
      width: 46,
      height: 46,
      alignment: Alignment.center,
      decoration: BoxDecoration(color: e.bg, borderRadius: BorderRadius.circular(12), border: Border.all(color: x.textAccent.withAlpha(90))),
      child: Text('أب', style: TextStyle(color: e.ink, fontWeight: FontWeight.bold, fontSize: 16)),
    ),
    title: Text(e.name),
    subtitle: Text(e.sub),
    trailing: cur == i ? Icon(Icons.check_circle, color: x.textAccent) : null,
    onTap: () {
      AppPrefs.setEye(i);
      Navigator.pop(ctx);
    },
  );
}

void showEyeModeSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (ctx) {
      final x = dx(ctx);
      return SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.84),
          child: ValueListenableBuilder<int>(
            valueListenable: AppPrefs.eye,
            builder: (ctx, cur, _) => ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.only(bottom: 12),
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(18, 16, 18, 2),
                  child: Text('وضع راحة العين', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(18, 0, 18, 8),
                  child: Text('اختر الوضع الأنسب لعينيك. يُطبَّق على قراءة الكتب، ويمكنك تعميمه على التطبيق كله.', style: TextStyle(fontSize: 13, height: 1.6)),
                ),
                ValueListenableBuilder<bool>(
                  valueListenable: AppPrefs.eyeAppWide,
                  builder: (ctx, wide, _) => SwitchListTile(
                    secondary: const Icon(Icons.phone_android),
                    title: const Text('تطبيق الوضع على كامل التطبيق'),
                    subtitle: const Text('يشمل الرئيسية والمكتبة والقوائم، لا القراءة وحدها'),
                    value: wide,
                    onChanged: (v) => AppPrefs.setAppWide(v),
                  ),
                ),
                const Divider(height: 1),
                for (int i = 0; i < eyeModes.length; i++) _eyeTile(ctx, x, i, cur),
              ],
            ),
          ),
        ),
      );
    },
  );
}

// ════════════════════════════════════════════════════════════
//  قائمة الكتب (تحت بعضها)
// ════════════════════════════════════════════════════════════

const _bookBlues = <Color>[
  Color(0xFF123F7A),
  Color(0xFF1B5FAE),
  Color(0xFF0F2F5C),
  Color(0xFF2A55A8),
];

Widget _bookCard(DesignExt x, Book b, int idx, int? mark, VoidCallback onTap) {
  // أغلفة تتبادل بين الأزرق والبرتقالي
  final orangeCover = idx.isOdd;
  final base = _bookBlues[idx % _bookBlues.length];
  final coverColors = orangeCover ? const [Color(0xFFF7A74F), Color(0xFFE2740F)] : [base, Color.lerp(base, Colors.black, 0.35)!];
  final onCover = orangeCover ? const Color(0xFF0F2F5C) : Colors.white;
  final numColor = orangeCover ? Colors.white : const Color(0xFFF28C28);
  final sub = b.isMulti ? '${ar(b.parts.length)} أجزاء' : 'ملف PDF';
  Widget chip(IconData icon, String label, Color fg) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
    decoration: BoxDecoration(color: fg.withAlpha(28), borderRadius: BorderRadius.circular(20)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 14, color: fg),
      const SizedBox(width: 4),
      Text(label, style: TextStyle(color: fg, fontSize: 12, fontWeight: FontWeight.w700)),
    ]),
  );
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Container(
      decoration: BoxDecoration(
        color: x.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: x.textAccent.withAlpha(45)),
        boxShadow: [BoxShadow(color: Colors.black.withAlpha(x.dark ? 60 : 18), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(18),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Container(
                width: 60,
                height: 82,
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(
                  gradient: LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: coverColors),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: orangeCover ? const Color(0xFF123F7A) : const Color(0xFFF28C28), width: 1.3),
                ),
                child: Column(children: [
                  Expanded(
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.menu_book_rounded, size: 26, color: onCover),
                      const SizedBox(height: 4),
                      Text(ar(idx + 1), style: TextStyle(color: numColor, fontWeight: FontWeight.w800, fontSize: 15)),
                    ]),
                  ),
                  Container(height: 7, color: orangeCover ? const Color(0xFF123F7A) : const Color(0xFFF28C28)),
                ]),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(b.title, maxLines: 3, overflow: TextOverflow.ellipsis, style: TextStyle(color: x.ink, fontSize: 15.5, fontWeight: FontWeight.w800, height: 1.5)),
                  const SizedBox(height: 8),
                  Wrap(spacing: 6, runSpacing: 4, children: [
                    chip(b.isMulti ? Icons.layers_outlined : Icons.picture_as_pdf_outlined, sub, x.muted),
                    if (mark != null) chip(Icons.bookmark, marksLabel(mark), x.textAccent),
                  ]),
                ]),
              ),
              const SizedBox(width: 6),
              Icon(Icons.chevron_left, color: x.highlight, size: 26),
            ]),
          ),
        ),
      ),
    ),
  );
}

Widget _listHeader(DesignExt x, int n, int totalMarks, Widget? trailing) {
  final sub = totalMarks == 0 ? 'اضغط على أي كتاب لبدء القراءة.' : 'لديك ${marksLabel(totalMarks)} محفوظة.';
  return Container(
    margin: const EdgeInsets.only(bottom: 14),
    padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
    decoration: BoxDecoration(color: x.card, borderRadius: BorderRadius.circular(18), border: Border.all(color: x.textAccent.withAlpha(90))),
    child: Row(children: [
      Icon(Icons.library_books, color: x.textAccent, size: 32),
      const SizedBox(width: 12),
      Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(booksLabel(n), style: TextStyle(color: x.ink, fontWeight: FontWeight.w800, fontSize: 18)),
          Text(sub, style: TextStyle(color: x.muted, fontSize: 12.5)),
        ]),
      ),
      if (trailing != null) trailing,
    ]),
  );
}

Widget _searchBox(DesignExt x, TextEditingController ctl, String q, ValueChanged<String> onQuery) {
  const r = 18.0;
  return TextField(
    controller: ctl,
    onChanged: onQuery,
    style: TextStyle(color: x.ink),
    decoration: InputDecoration(
      hintText: 'ابحث في الكتب...',
      hintStyle: TextStyle(color: x.muted),
      prefixIcon: Icon(Icons.search, color: x.textAccent),
      suffixIcon: q.isEmpty
          ? null
          : IconButton(
              icon: Icon(Icons.close, color: x.muted),
              onPressed: () {
                ctl.clear();
                onQuery('');
              },
            ),
      filled: true,
      fillColor: x.card,
      contentPadding: EdgeInsets.zero,
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(r), borderSide: BorderSide(color: x.textAccent.withAlpha(80))),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(r), borderSide: BorderSide(color: x.textAccent, width: 1.6)),
    ),
  );
}

Widget designBookListBody(
  BuildContext context,
  DesignExt x, {
  required List<Book> all,
  required List<int> shown,
  required Map<String, int> marks,
  required String q,
  required TextEditingController ctl,
  required ValueChanged<String> onQuery,
  required Future<void> Function(Book) onOpen,
  Widget? trailing,
  Widget? top,
}) {
  final totalMarks = marks.values.fold<int>(0, (a, b) => a + b);
  return CustomScrollView(slivers: [
      SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            if (top != null) top,
            _listHeader(x, all.length, totalMarks, trailing),
            _searchBox(x, ctl, q, onQuery),
            const SizedBox(height: 14),
          ]),
        ),
      ),
      if (shown.isEmpty)
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(30), child: Center(child: Text('لا توجد كتب مطابقة.', style: TextStyle(color: x.muted)))))
      else
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
          sliver: SliverList(
            delegate: SliverChildBuilderDelegate((c, i) {
              final idx = shown[i];
              final b = all[idx];
              return _bookCard(x, b, idx, marks[b.asset], () => onOpen(b));
            }, childCount: shown.length),
          ),
        ),
  ]);
}

// ════════════════════════════════════════════════════════════
//  خلفية هادئة للتطبيق: تدرّج ناعم + نقش نجوم خافت + أقواس
// ════════════════════════════════════════════════════════════

class CalmBackground extends StatelessWidget {
  const CalmBackground({super.key});
  @override
  Widget build(BuildContext context) {
    final x = dx(context);
    return IgnorePointer(
      child: RepaintBoundary(
        child: CustomPaint(
          size: Size.infinite,
          painter: _CalmBgPainter(x.bg, x.textAccent, x.highlight, x.dark),
        ),
      ),
    );
  }
}

class _CalmBgPainter extends CustomPainter {
  final Color bg;
  final Color accent;
  final Color gold;
  final bool dark;
  const _CalmBgPainter(this.bg, this.accent, this.gold, this.dark);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    // تدرّج ناعم
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color.lerp(bg, accent, dark ? 0.10 : 0.07)!,
            bg,
            Color.lerp(bg, gold, dark ? 0.08 : 0.14)!,
          ],
          stops: const [0.0, 0.55, 1.0],
        ).createShader(rect),
    );
    // وهج ذهبي في الأعلى ووهج فيروزي في الأسفل
    void glow(Offset c, double r, Color col, int a) {
      canvas.drawCircle(
        c,
        r,
        Paint()..shader = RadialGradient(colors: [col.withAlpha(a), col.withAlpha(0)]).createShader(Rect.fromCircle(center: c, radius: r)),
      );
    }
    glow(Offset(size.width * 0.9, size.height * 0.06), size.width * 0.8, gold, dark ? 34 : 60);
    glow(Offset(size.width * 0.05, size.height * 0.96), size.width * 0.9, accent, dark ? 40 : 34);
    // نقش النجوم الإسلامي الخافت
    PatternPainter(accent.withAlpha(dark ? 20 : 18), cell: 56).paint(canvas, size);
    // أقواس المحراب المتداخلة أسفل الشاشة
    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = accent.withAlpha(dark ? 38 : 30);
    final cx = size.width / 2;
    final cy = size.height * 0.9;
    for (int i = 0; i < 3; i++) {
      final r = size.width * (0.52 - i * 0.11);
      final path = Path()
        ..moveTo(cx - r, size.height)
        ..lineTo(cx - r, cy)
        ..arcTo(Rect.fromCircle(center: Offset(cx, cy), radius: r), math.pi, math.pi, false)
        ..lineTo(cx + r, size.height);
      canvas.drawPath(path, line);
    }
  }

  @override
  bool shouldRepaint(_CalmBgPainter old) => old.bg != bg || old.accent != accent || old.gold != gold || old.dark != dark;
}

// يضع الخلفية الهادئة خلف محتوى أي شاشة
class CalmBody extends StatelessWidget {
  final Widget child;
  const CalmBody({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Stack(fit: StackFit.expand, children: [
    const Positioned.fill(child: CalmBackground()),
    child,
  ]);
}
